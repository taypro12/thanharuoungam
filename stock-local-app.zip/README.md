# STOCK LOCAL – Web App tra cứu tồn kho SAP trong mạng LAN

Bản MVP chạy hoàn toàn trong mạng nội bộ. Người dùng **không upload dữ liệu từ trình duyệt**. Backend đọc file SAP từ thư mục cấu hình sẵn.

## Chức năng hiện có

- Dashboard: tổng vật tư, an toàn, theo dõi, cần mua, hết hàng.
- Tra cứu theo mã vật tư / mô tả / part number / manufacturer.
- Xem tồn Unrestricted, Reserved, Available.
- Đọc lịch sử movement từ MB51.
- Tự tính Usage 30/90/365 ngày.
- Tự tính Average Daily Usage, Safety Stock, ROP, Min, Max.
- Tự tính Coverage Days và ngày dự kiến hết hàng.
- Cảnh báo SAFE / WATCH / CRITICAL / OUT OF STOCK.
- Backend chỉ đọc file Excel nguồn, không sửa/xóa file SAP.
- Bỏ qua file đã import bằng SHA-256 checksum.
- Chạy LAN: `http://IP-MAY-CHU:8080`.

## Cấu trúc

```text
stock-local-app/
├─ backend/
│  ├─ app/
│  ├─ config.json
│  └─ requirements.txt
├─ frontend/          <- HTML/CSS/JS chạy offline, không CDN
├─ data/
│  ├─ import/        <- đặt MB51/MB52 tại đây
│  └─ stock.db
├─ start.bat
└─ dev.bat
```

## Cách chạy trên Windows

1. Cài Python 3.11+ trên **máy chạy server**. Không cần Node.js.
2. Copy file SAP vào `data\import`:
   - tên file có chữ `MB52`, ví dụ `MB52_20260909.xlsx`
   - tên file có chữ `MB51`, ví dụ `MB51_20260909.xlsx`
3. Double-click `start.bat`.
4. Mở `http://localhost:8080`.
5. Máy khác cùng LAN mở `http://IP-MAY-CHU:8080`.

## Đổi thư mục SAP nguồn

Sửa `backend/config.json`, ví dụ:

```json
{
  "import_folder": "D:/STOCK_DATA/IMPORT",
  "database_path": "../data/stock.db",
  "auto_sync_on_start": true,
  "default_safety_days": 14,
  "default_lead_time_days": 30,
  "default_review_days": 30
}
```

Hoặc dùng ổ mạng đọc-only:

```json
"import_folder": "//SERVER/SAP_EXPORT/STOCK"
```

Tài khoản Windows chạy app cần có quyền **Read** trên thư mục đó.

## Logic tính tồn / ROP ở MVP

- `Available = Unrestricted - Reserved`
- Usage tính từ MB51 theo movement type:
  - xuất: 201, 261, 281, 601, 551
  - hoàn/reversal: 202, 262, 282, 602, 552
- `Avg Daily Usage = Usage 365D / 365` (fallback 90D/30D)
- `Safety Stock = Avg Daily Usage × Safety Days`
- `ROP = Avg Daily Usage × Lead Time Days + Safety Stock`
- `Max = ROP + Avg Daily Usage × Review Days`
- `Coverage = Available / Avg Daily Usage`

> Công thức này là baseline. Với dữ liệu thật của công ty nên điều chỉnh theo lead time, service level và biến động nhu cầu từng nhóm vật tư.

## Cột Excel được nhận diện

App có cơ chế alias để nhận các tên cột SAP thông dụng như Material, Material Description, Plant, Storage Location, Unrestricted, Posting Date, Movement Type, Quantity, Material Document…

Nếu file export thực tế dùng tên cột khác, chỉnh danh sách alias trong `backend/app/importer.py`.

## Bảo mật / triển khai nội bộ

- Không mở port 8080 ra Internet.
- Chỉ bind trong LAN/VLAN công ty theo chính sách IT.
- Nếu nhiều phòng ban sử dụng, nên nhờ IT cấp DNS nội bộ, ví dụ `http://stock.local`.
- Có thể bổ sung đăng nhập Windows/AD ở phiên bản tiếp theo.
