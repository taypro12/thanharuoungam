from __future__ import annotations
import sqlite3
from pathlib import Path
from contextlib import contextmanager

BASE_DIR = Path(__file__).resolve().parents[2]

SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS materials (
    material TEXT PRIMARY KEY,
    description TEXT DEFAULT '',
    uom TEXT DEFAULT '',
    material_group TEXT DEFAULT '',
    manufacturer TEXT DEFAULT '',
    part_number TEXT DEFAULT '',
    plant TEXT DEFAULT '',
    sloc TEXT DEFAULT '',
    unrestricted REAL DEFAULT 0,
    quality REAL DEFAULT 0,
    blocked REAL DEFAULT 0,
    reserved REAL DEFAULT 0,
    available REAL DEFAULT 0,
    safety_stock REAL DEFAULT 0,
    rop REAL DEFAULT 0,
    min_stock REAL DEFAULT 0,
    max_stock REAL DEFAULT 0,
    avg_daily_usage REAL DEFAULT 0,
    usage_30d REAL DEFAULT 0,
    usage_90d REAL DEFAULT 0,
    usage_365d REAL DEFAULT 0,
    coverage_days REAL,
    estimated_stockout_date TEXT,
    status TEXT DEFAULT 'UNKNOWN',
    updated_at TEXT
);

CREATE TABLE IF NOT EXISTS movements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    material TEXT NOT NULL,
    posting_date TEXT,
    movement_type TEXT,
    quantity REAL DEFAULT 0,
    document TEXT DEFAULT '',
    plant TEXT DEFAULT '',
    sloc TEXT DEFAULT '',
    description TEXT DEFAULT '',
    source_file TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_movements_material_date ON movements(material, posting_date);

CREATE TABLE IF NOT EXISTS imports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_type TEXT NOT NULL,
    file_name TEXT NOT NULL,
    file_path TEXT NOT NULL,
    checksum TEXT NOT NULL,
    row_count INTEGER DEFAULT 0,
    imported_at TEXT NOT NULL,
    UNIQUE(source_type, checksum)
);

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
);
"""

def resolve_db_path(config: dict) -> Path:
    raw = Path(config.get("database_path", "../data/stock.db"))
    if raw.is_absolute():
        return raw
    return (BASE_DIR / "backend" / raw).resolve()

@contextmanager
def connect(db_path: Path):
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()

def init_db(db_path: Path):
    with connect(db_path) as conn:
        conn.executescript(SCHEMA)
