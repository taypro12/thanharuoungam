from __future__ import annotations
import json
from pathlib import Path
from datetime import datetime

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from .db import BASE_DIR, connect, init_db, resolve_db_path
from .importer import sync_folder

BACKEND_DIR = Path(__file__).resolve().parents[1]
CONFIG_PATH = BACKEND_DIR / "config.json"
CONFIG = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
DB_PATH = resolve_db_path(CONFIG)
raw_import = Path(CONFIG.get("import_folder", "../data/import"))
IMPORT_FOLDER = raw_import if raw_import.is_absolute() else (BACKEND_DIR / raw_import).resolve()
FRONTEND_DIST = BASE_DIR / "frontend"

app = FastAPI(title="Stock Local App", version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"],
)

@app.on_event("startup")
def startup():
    init_db(DB_PATH)
    if CONFIG.get("auto_sync_on_start", True):
        try:
            sync_folder(IMPORT_FOLDER, DB_PATH, CONFIG)
        except Exception:
            pass

@app.get("/api/health")
def health():
    return {"ok": True, "database": str(DB_PATH), "import_folder": str(IMPORT_FOLDER)}

@app.get("/api/dashboard")
def dashboard():
    with connect(DB_PATH) as conn:
        total = conn.execute("SELECT COUNT(*) c FROM materials").fetchone()["c"]
        status_rows = conn.execute("SELECT status, COUNT(*) c FROM materials GROUP BY status").fetchall()
        status = {r["status"]: r["c"] for r in status_rows}
        latest = conn.execute("SELECT source_type,file_name,imported_at,row_count FROM imports ORDER BY imported_at DESC LIMIT 1").fetchone()
        critical = conn.execute("""
            SELECT material,description,available,rop,coverage_days,status
            FROM materials WHERE status IN ('CRITICAL','OUT_OF_STOCK','WATCH')
            ORDER BY CASE status WHEN 'OUT_OF_STOCK' THEN 0 WHEN 'CRITICAL' THEN 1 ELSE 2 END, coverage_days ASC
            LIMIT 12
        """).fetchall()
        return {
            "total": total,
            "safe": status.get("SAFE",0),
            "watch": status.get("WATCH",0),
            "critical": status.get("CRITICAL",0),
            "out_of_stock": status.get("OUT_OF_STOCK",0),
            "latest_import": dict(latest) if latest else None,
            "critical_items": [dict(r) for r in critical],
        }

@app.get("/api/materials")
def materials(
    q: str = "",
    status: str = "",
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=500),
):
    where = []
    params = []
    if q.strip():
        term = f"%{q.strip()}%"
        where.append("(material LIKE ? OR description LIKE ? OR part_number LIKE ? OR manufacturer LIKE ?)")
        params += [term, term, term, term]
    if status.strip():
        where.append("status=?")
        params.append(status.strip())
    sql_where = " WHERE " + " AND ".join(where) if where else ""
    offset = (page - 1) * page_size
    with connect(DB_PATH) as conn:
        total = conn.execute("SELECT COUNT(*) c FROM materials" + sql_where, params).fetchone()["c"]
        rows = conn.execute("""
            SELECT material,description,uom,plant,sloc,unrestricted,reserved,available,
                   safety_stock,rop,avg_daily_usage,usage_30d,usage_90d,coverage_days,
                   estimated_stockout_date,status,updated_at
            FROM materials
        """ + sql_where + " ORDER BY material LIMIT ? OFFSET ?", params + [page_size, offset]).fetchall()
    return {"items": [dict(r) for r in rows], "total": total, "page": page, "page_size": page_size}

@app.get("/api/materials/{material}")
def material_detail(material: str):
    with connect(DB_PATH) as conn:
        row = conn.execute("SELECT * FROM materials WHERE material=?", (material,)).fetchone()
        if not row:
            raise HTTPException(404, "Không tìm thấy vật tư")
        return dict(row)

@app.get("/api/materials/{material}/movements")
def material_movements(material: str, limit: int = Query(100, ge=1, le=1000)):
    with connect(DB_PATH) as conn:
        rows = conn.execute("""
            SELECT posting_date,movement_type,quantity,document,plant,sloc,description,source_file
            FROM movements WHERE material=? ORDER BY posting_date DESC, id DESC LIMIT ?
        """, (material, limit)).fetchall()
    return {"items": [dict(r) for r in rows]}

@app.post("/api/admin/sync")
def admin_sync():
    return sync_folder(IMPORT_FOLDER, DB_PATH, CONFIG)

@app.get("/api/admin/import-history")
def import_history():
    with connect(DB_PATH) as conn:
        rows = conn.execute("SELECT source_type,file_name,row_count,imported_at FROM imports ORDER BY imported_at DESC LIMIT 100").fetchall()
    return {"items": [dict(r) for r in rows], "import_folder": str(IMPORT_FOLDER)}

# Serve production React build if it exists.
if FRONTEND_DIST.exists():
    @app.get("/{full_path:path}")
    def spa(full_path: str):
        requested = FRONTEND_DIST / full_path
        if full_path and requested.is_file():
            return FileResponse(requested)
        return FileResponse(FRONTEND_DIST / "index.html")
