from __future__ import annotations
import hashlib
import json
import math
import re
from datetime import datetime, timedelta
from pathlib import Path
from typing import Iterable

import pandas as pd

from .db import connect

OUTBOUND = {"201", "261", "281", "601", "551"}
REVERSAL = {"202", "262", "282", "602", "552"}

ALIASES_MB52 = {
    "material": ["material", "material number", "mã vật tư", "ma vat tu"],
    "description": ["material description", "description", "material desc", "mô tả vật tư", "mo ta vat tu"],
    "uom": ["base unit of measure", "base unit", "uom", "unit", "đvt", "dvt"],
    "material_group": ["material group", "matl group", "nhóm vật tư", "nhom vat tu"],
    "plant": ["plant", "nhà máy", "nha may"],
    "sloc": ["storage location", "stor. loc.", "sloc", "kho"],
    "unrestricted": ["unrestricted", "unrestricted-use stock", "unrestricted stock", "tồn tự do", "ton tu do"],
    "quality": ["stock in quality insp.", "quality inspection", "quality", "qi stock"],
    "blocked": ["blocked", "blocked stock"],
    "reserved": ["reserved", "reserved stock", "reservation"],
}

ALIASES_MB51 = {
    "material": ["material", "material number", "mã vật tư", "ma vat tu"],
    "description": ["material description", "description", "material desc", "mô tả vật tư", "mo ta vat tu"],
    "posting_date": ["posting date", "postg date", "ngày hạch toán", "ngay hach toan"],
    "movement_type": ["movement type", "mvt", "movement", "loại chuyển động", "loai chuyen dong"],
    "quantity": ["quantity", "qty", "số lượng", "so luong"],
    "document": ["material document", "mat. doc.", "document", "chứng từ", "chung tu"],
    "plant": ["plant", "nhà máy", "nha may"],
    "sloc": ["storage location", "stor. loc.", "sloc", "kho"],
}

def norm(s: object) -> str:
    text = str(s or "").strip().lower()
    text = re.sub(r"\s+", " ", text)
    return text

def detect_columns(df: pd.DataFrame, aliases: dict[str, list[str]]) -> dict[str, str]:
    norm_map = {norm(c): c for c in df.columns}
    result = {}
    for logical, options in aliases.items():
        for opt in options:
            if norm(opt) in norm_map:
                result[logical] = norm_map[norm(opt)]
                break
    return result

def read_excel_flexible(path: Path) -> pd.DataFrame:
    # SAP exports may contain title rows. Find first row that looks like a header.
    raw = pd.read_excel(path, header=None, dtype=object)
    header_row = 0
    for i in range(min(20, len(raw))):
        row = [norm(v) for v in raw.iloc[i].tolist()]
        score = sum(1 for v in row if v in {"material", "material number", "posting date", "movement type", "plant", "storage location"})
        if score >= 1:
            header_row = i
            break
    return pd.read_excel(path, header=header_row, dtype=object)

def to_num(v) -> float:
    if pd.isna(v):
        return 0.0
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip().replace(" ", "")
    # handle common thousands separators while preserving decimals reasonably
    if s.count(",") == 1 and s.count(".") == 0:
        tail = s.split(",")[-1]
        s = s.replace(",", ".") if len(tail) <= 3 else s.replace(",", "")
    else:
        s = s.replace(",", "")
    try:
        return float(s)
    except Exception:
        return 0.0

def clean_material(v) -> str:
    if pd.isna(v):
        return ""
    s = str(v).strip()
    if s.endswith(".0") and s[:-2].isdigit():
        s = s[:-2]
    return s

def file_hash(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def import_exists(conn, source_type: str, checksum: str) -> bool:
    return conn.execute("SELECT 1 FROM imports WHERE source_type=? AND checksum=?", (source_type, checksum)).fetchone() is not None

def record_import(conn, source_type: str, path: Path, checksum: str, rows: int):
    conn.execute(
        "INSERT OR IGNORE INTO imports(source_type,file_name,file_path,checksum,row_count,imported_at) VALUES(?,?,?,?,?,?)",
        (source_type, path.name, str(path), checksum, rows, datetime.now().isoformat(timespec="seconds")),
    )

def import_mb52(path: Path, db_path: Path) -> dict:
    checksum = file_hash(path)
    with connect(db_path) as conn:
        if import_exists(conn, "MB52", checksum):
            return {"source": "MB52", "file": path.name, "skipped": True, "rows": 0}

    df = read_excel_flexible(path)
    cols = detect_columns(df, ALIASES_MB52)
    if "material" not in cols or "unrestricted" not in cols:
        raise ValueError(f"MB52 thiếu cột bắt buộc Material/Unrestricted. Cột nhận được: {list(df.columns)}")

    grouped = {}
    for _, r in df.iterrows():
        material = clean_material(r.get(cols["material"]))
        if not material or material.lower() == "nan":
            continue
        key = material
        item = grouped.setdefault(key, {
            "material": material,
            "description": "", "uom": "", "material_group": "", "plant": "", "sloc": "",
            "unrestricted": 0.0, "quality": 0.0, "blocked": 0.0, "reserved": 0.0,
        })
        for k in ["description", "uom", "material_group", "plant", "sloc"]:
            if k in cols and not item[k]:
                val = r.get(cols[k])
                if not pd.isna(val): item[k] = str(val).strip()
        for k in ["unrestricted", "quality", "blocked", "reserved"]:
            if k in cols:
                item[k] += to_num(r.get(cols[k]))

    now = datetime.now().isoformat(timespec="seconds")
    with connect(db_path) as conn:
        for x in grouped.values():
            available = x["unrestricted"] - x["reserved"]
            conn.execute("""
                INSERT INTO materials(material,description,uom,material_group,plant,sloc,unrestricted,quality,blocked,reserved,available,updated_at)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(material) DO UPDATE SET
                    description=excluded.description,
                    uom=excluded.uom,
                    material_group=excluded.material_group,
                    plant=excluded.plant,
                    sloc=excluded.sloc,
                    unrestricted=excluded.unrestricted,
                    quality=excluded.quality,
                    blocked=excluded.blocked,
                    reserved=excluded.reserved,
                    available=excluded.available,
                    updated_at=excluded.updated_at
            """, (x["material"], x["description"], x["uom"], x["material_group"], x["plant"], x["sloc"], x["unrestricted"], x["quality"], x["blocked"], x["reserved"], available, now))
        record_import(conn, "MB52", path, checksum, len(grouped))
    return {"source": "MB52", "file": path.name, "skipped": False, "rows": len(grouped)}

def import_mb51(path: Path, db_path: Path) -> dict:
    checksum = file_hash(path)
    with connect(db_path) as conn:
        if import_exists(conn, "MB51", checksum):
            return {"source": "MB51", "file": path.name, "skipped": True, "rows": 0}

    df = read_excel_flexible(path)
    cols = detect_columns(df, ALIASES_MB51)
    required = ["material", "posting_date", "movement_type", "quantity"]
    missing = [c for c in required if c not in cols]
    if missing:
        raise ValueError(f"MB51 thiếu cột: {', '.join(missing)}. Cột nhận được: {list(df.columns)}")

    rows = []
    for _, r in df.iterrows():
        material = clean_material(r.get(cols["material"]))
        if not material or material.lower() == "nan":
            continue
        dt = pd.to_datetime(r.get(cols["posting_date"]), errors="coerce", dayfirst=True)
        posting_date = dt.date().isoformat() if not pd.isna(dt) else None
        mvt = clean_material(r.get(cols["movement_type"]))
        quantity = abs(to_num(r.get(cols["quantity"])))
        def val(name):
            if name not in cols: return ""
            v = r.get(cols[name])
            return "" if pd.isna(v) else str(v).strip()
        rows.append((material, posting_date, mvt, quantity, val("document"), val("plant"), val("sloc"), val("description"), path.name))

    with connect(db_path) as conn:
        conn.executemany("""
            INSERT INTO movements(material,posting_date,movement_type,quantity,document,plant,sloc,description,source_file)
            VALUES(?,?,?,?,?,?,?,?,?)
        """, rows)
        # ensure materials exist even if MB52 doesn't contain them yet
        for material, _, _, _, _, plant, sloc, description, _ in rows:
            conn.execute("""
                INSERT INTO materials(material,description,plant,sloc,updated_at)
                VALUES(?,?,?,?,?) ON CONFLICT(material) DO NOTHING
            """, (material, description, plant, sloc, datetime.now().isoformat(timespec="seconds")))
        record_import(conn, "MB51", path, checksum, len(rows))
    return {"source": "MB51", "file": path.name, "skipped": False, "rows": len(rows)}

def recalc_inventory(db_path: Path, config: dict):
    safety_days = float(config.get("default_safety_days", 14))
    lead_days = float(config.get("default_lead_time_days", 30))
    review_days = float(config.get("default_review_days", 30))
    today = datetime.now().date()

    with connect(db_path) as conn:
        mats = conn.execute("SELECT material, available FROM materials").fetchall()
        for mat in mats:
            material = mat["material"]
            usage = {}
            for days in (30, 90, 365):
                start = (today - timedelta(days=days)).isoformat()
                rows = conn.execute("""
                    SELECT movement_type, quantity FROM movements
                    WHERE material=? AND posting_date>=?
                """, (material, start)).fetchall()
                total = 0.0
                for r in rows:
                    mvt = str(r["movement_type"] or "")
                    qty = float(r["quantity"] or 0)
                    if mvt in OUTBOUND: total += qty
                    elif mvt in REVERSAL: total -= qty
                usage[days] = max(0.0, total)
            avg_daily = usage[365] / 365.0 if usage[365] > 0 else usage[90] / 90.0 if usage[90] > 0 else usage[30] / 30.0 if usage[30] > 0 else 0.0
            safety_stock = avg_daily * safety_days
            rop = avg_daily * lead_days + safety_stock
            min_stock = rop
            max_stock = rop + avg_daily * review_days
            available = float(mat["available"] or 0)
            coverage = (available / avg_daily) if avg_daily > 0 else None
            stockout = (today + timedelta(days=max(0, math.ceil(coverage)))).isoformat() if coverage is not None else None
            if available <= 0:
                status = "OUT_OF_STOCK"
            elif available <= safety_stock and safety_stock > 0:
                status = "CRITICAL"
            elif available <= rop and rop > 0:
                status = "WATCH"
            else:
                status = "SAFE"
            conn.execute("""
                UPDATE materials SET usage_30d=?, usage_90d=?, usage_365d=?, avg_daily_usage=?,
                safety_stock=?, rop=?, min_stock=?, max_stock=?, coverage_days=?, estimated_stockout_date=?, status=?
                WHERE material=?
            """, (usage[30], usage[90], usage[365], avg_daily, safety_stock, rop, min_stock, max_stock, coverage, stockout, status, material))

def sync_folder(import_folder: Path, db_path: Path, config: dict) -> dict:
    import_folder.mkdir(parents=True, exist_ok=True)
    files = sorted([p for p in import_folder.iterdir() if p.suffix.lower() in {".xlsx", ".xlsm", ".xls"}])
    results = []
    errors = []
    # Import MB52 first so current stock exists before analytics.
    ordered = sorted(files, key=lambda p: (0 if "mb52" in p.name.lower() else 1, p.name.lower()))
    for path in ordered:
        try:
            lname = path.name.lower()
            if "mb52" in lname:
                results.append(import_mb52(path, db_path))
            elif "mb51" in lname:
                results.append(import_mb51(path, db_path))
        except Exception as e:
            errors.append({"file": path.name, "error": str(e)})
    recalc_inventory(db_path, config)
    return {"results": results, "errors": errors, "folder": str(import_folder)}
