@echo off
setlocal
cd /d "%~dp0"
echo =============================================
echo   STOCK LOCAL - Khoi dong ung dung noi bo
echo =============================================
if not exist ".venv\Scripts\python.exe" (
  echo [1/3] Tao moi truong Python...
  py -m venv .venv
)
echo [2/3] Cai/kiem tra thu vien...
call .venv\Scripts\activate.bat
python -m pip install -q -r backend\requirements.txt
if errorlevel 1 (
  echo.
  echo Khong the cai thu vien. Kiem tra Internet/proxy hoac nho IT cai Python packages.
  pause
  exit /b 1
)
echo [3/3] Khoi dong server...
echo.
echo Mo tren may nay: http://localhost:8080
echo May khac trong LAN: http://IP-MAY-NAY:8080
echo.
cd backend
python run.py
