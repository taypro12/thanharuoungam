@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" py -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install -q -r backend\requirements.txt
cd backend
python -m uvicorn app.main:app --host 0.0.0.0 --port 8080 --reload
