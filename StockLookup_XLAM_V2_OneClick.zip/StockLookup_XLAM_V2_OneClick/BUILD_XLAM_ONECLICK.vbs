Option Explicit

Dim fso, sh, root, src, outDir, outPath
Dim xl, wb, vbProj, modComp, formComp, designer, twbComp
Dim errFile

Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")

root = fso.GetParentFolderName(WScript.ScriptFullName)
src = fso.BuildPath(root, "src")
outDir = fso.BuildPath(root, "OUTPUT")
outPath = fso.BuildPath(outDir, "StockLookup.xlam")
errFile = fso.BuildPath(root, "BUILD_ERROR.txt")

On Error Resume Next
If fso.FileExists(errFile) Then fso.DeleteFile errFile, True
On Error GoTo 0

If Not fso.FolderExists(outDir) Then fso.CreateFolder outDir

If Not CheckSourceFiles() Then
    Fail 10, "Thieu file ma nguon trong thu muc src."
End If

On Error Resume Next
Set xl = CreateObject("Excel.Application")
If Err.Number <> 0 Or xl Is Nothing Then
    Fail 20, "Khong mo duoc Microsoft Excel desktop." & vbCrLf & _
             "Hay chay bo tao nay tren may Windows co cai Excel."
End If
Err.Clear
On Error GoTo 0

xl.Visible = False
xl.DisplayAlerts = False
xl.ScreenUpdating = False
xl.EnableEvents = False

On Error Resume Next
Set wb = xl.Workbooks.Add
If Err.Number <> 0 Or wb Is Nothing Then
    FailWithExcel 21, "Excel mo duoc nhung khong tao duoc workbook tam: " & Err.Description
End If
Err.Clear

Set vbProj = wb.VBProject
If Err.Number <> 0 Or vbProj Is Nothing Then
    FailWithExcel 30, _
        "Excel dang chan quyen tao VBA Project." & vbCrLf & vbCrLf & _
        "Bat TAM THOI tuy chon sau tren MAY TAO XLAM:" & vbCrLf & _
        "File > Options > Trust Center > Trust Center Settings > Macro Settings >" & vbCrLf & _
        "Trust access to the VBA project object model." & vbCrLf & vbCrLf & _
        "Sau khi StockLookup.xlam duoc tao xong, co the tat lai tuy chon nay." & vbCrLf & _
        "May cong ty chi can nap file XLAM thanh pham, khong can bat quyen nay."
End If
Err.Clear
On Error GoTo 0

' ----- Standard VBA module -----
On Error Resume Next
Set modComp = vbProj.VBComponents.Add(1)
If Err.Number <> 0 Or modComp Is Nothing Then
    FailWithExcel 40, "Khong tao duoc VBA Standard Module: " & Err.Description
End If
Err.Clear
modComp.Name = "modStockLookup"
modComp.CodeModule.AddFromString ReadAll(fso.BuildPath(src, "modStockLookup.bas"))
If Err.Number <> 0 Then
    FailWithExcel 41, "Khong nap duoc modStockLookup.bas: " & Err.Description
End If
Err.Clear

' ----- UserForm -----
Set formComp = vbProj.VBComponents.Add(3)
If Err.Number <> 0 Or formComp Is Nothing Then
    FailWithExcel 50, "Khong tao duoc UserForm: " & Err.Description
End If
Err.Clear
formComp.Name = "frmStockLookup"
formComp.Properties("Caption") = "Tra cuu ton kho - Stock Lookup"
formComp.Properties("Width") = 835
formComp.Properties("Height") = 520
Set designer = formComp.Designer
If Err.Number <> 0 Or designer Is Nothing Then
    FailWithExcel 51, "Khong mo duoc UserForm Designer: " & Err.Description
End If
Err.Clear

BuildForm designer
If Err.Number <> 0 Then
    FailWithExcel 52, "Loi tao giao dien UserForm: " & Err.Description
End If
Err.Clear

formComp.CodeModule.AddFromString ReadAll(fso.BuildPath(src, "frmStockLookup_Code.txt"))
If Err.Number <> 0 Then
    FailWithExcel 53, "Khong nap duoc code UserForm: " & Err.Description
End If
Err.Clear

' ----- ThisWorkbook events -----
Set twbComp = vbProj.VBComponents("ThisWorkbook")
If Err.Number <> 0 Or twbComp Is Nothing Then
    FailWithExcel 60, "Khong truy cap duoc ThisWorkbook: " & Err.Description
End If
Err.Clear
If twbComp.CodeModule.CountOfLines > 0 Then
    twbComp.CodeModule.DeleteLines 1, twbComp.CodeModule.CountOfLines
End If
twbComp.CodeModule.AddFromString ReadAll(fso.BuildPath(src, "ThisWorkbook_Code.txt"))
If Err.Number <> 0 Then
    FailWithExcel 61, "Khong nap duoc code ThisWorkbook: " & Err.Description
End If
Err.Clear
On Error GoTo 0

' ----- Add-in workbook setup -----
On Error Resume Next
wb.Worksheets(1).Name = "_ADDIN"
wb.IsAddin = True
On Error GoTo 0

If fso.FileExists(outPath) Then
    On Error Resume Next
    fso.DeleteFile outPath, True
    If Err.Number <> 0 Then
        FailWithExcel 70, "Khong ghi de duoc file XLAM cu. Hay dong StockLookup.xlam neu dang mo."
    End If
    On Error GoTo 0
End If

' Excel file format 55 = xlOpenXMLAddIn (*.xlam)
On Error Resume Next
wb.SaveAs outPath, 55
If Err.Number <> 0 Then
    Dim saveErr
    saveErr = Err.Description
    Err.Clear
    FailWithExcel 71, "Khong luu duoc StockLookup.xlam: " & saveErr
End If
On Error GoTo 0

On Error Resume Next
wb.Close False
Set wb = Nothing
xl.EnableEvents = True
xl.ScreenUpdating = True
xl.Quit
Set xl = Nothing
On Error GoTo 0

If Not fso.FileExists(outPath) Then
    Fail 72, "Excel khong bao loi nhung file StockLookup.xlam khong ton tai sau khi luu."
End If

On Error Resume Next
sh.Run "explorer.exe /select,""" & outPath & """", 1, False
On Error GoTo 0

MsgBox "DA TAO XONG FILE XLAM!" & vbCrLf & vbCrLf & _
       outPath & vbCrLf & vbCrLf & _
       "Buoc tiep theo:" & vbCrLf & _
       "- Copy StockLookup.xlam sang may cong ty, hoac" & vbCrLf & _
       "- Chay CAI_DAT_ADDIN.bat tren may dang su dung Excel.", _
       64, "Stock Lookup XLAM V2"

WScript.Quit 0


Function CheckSourceFiles()
    CheckSourceFiles = _
        fso.FileExists(fso.BuildPath(src, "modStockLookup.bas")) And _
        fso.FileExists(fso.BuildPath(src, "frmStockLookup_Code.txt")) And _
        fso.FileExists(fso.BuildPath(src, "ThisWorkbook_Code.txt"))
End Function

Sub Fail(code, message)
    WriteError code, message
    MsgBox message & vbCrLf & vbCrLf & _
           "Chi tiet da luu vao:" & vbCrLf & errFile, 16, "Stock Lookup Builder"
    WScript.Quit code
End Sub

Sub FailWithExcel(code, message)
    On Error Resume Next
    If Not wb Is Nothing Then wb.Close False
    If Not xl Is Nothing Then
        xl.EnableEvents = True
        xl.ScreenUpdating = True
        xl.Quit
    End If
    On Error GoTo 0
    Fail code, message
End Sub

Sub WriteError(code, message)
    Dim ts
    On Error Resume Next
    Set ts = fso.CreateTextFile(errFile, True, False)
    ts.WriteLine "Stock Lookup XLAM V2 - BUILD ERROR"
    ts.WriteLine "Error code: " & code
    ts.WriteLine "Time: " & Now
    ts.WriteLine ""
    ts.WriteLine message
    ts.Close
    On Error GoTo 0
End Sub

Sub BuildForm(d)
    Dim c, fr

    Set c = AddLabel(d, "lblTitle", "TRA CUU TON KHO VAT TU", 14, 10, 420, 28, 18, True)
    Set c = AddLabel(d, "lblSource", "Nguon: chua chon", 14, 40, 780, 18, 9, False)

    Set c = AddTextBox(d, "txtSearch", 14, 66, 280, 24)
    Set c = AddCombo(d, "cboField", 302, 66, 120, 24)
    Set c = AddButton(d, "btnSearch", "Tim kiem", 430, 64, 72, 26)
    Set c = AddButton(d, "btnClear", "Xoa", 508, 64, 55, 26)
    Set c = AddButton(d, "btnChoose", "Chon file", 570, 64, 78, 26)
    Set c = AddButton(d, "btnReload", "Lam moi", 654, 64, 72, 26)
    Set c = AddButton(d, "btnClose", "Dong", 732, 64, 55, 26)

    Set c = AddLabel(d, "hMaterial", "Material", 14, 98, 75, 16, 8, True)
    Set c = AddLabel(d, "hDescription", "Description", 91, 98, 175, 16, 8, True)
    Set c = AddLabel(d, "hPlant", "Plant", 270, 98, 50, 16, 8, True)
    Set c = AddLabel(d, "hSloc", "SLoc", 325, 98, 55, 16, 8, True)
    Set c = AddLabel(d, "hStock", "Stock", 384, 98, 55, 16, 8, True)
    Set c = AddLabel(d, "hAvail", "Avail.", 443, 98, 55, 16, 8, True)
    Set c = AddLabel(d, "hRop", "ROP", 502, 98, 50, 16, 8, True)
    Set c = AddLabel(d, "hStatus", "Status", 556, 98, 70, 16, 8, True)

    Set c = d.Controls.Add("Forms.ListBox.1", "lstResults", True)
    c.Left = 14
    c.Top = 116
    c.Width = 530
    c.Height = 320
    c.IntegralHeight = False
    c.Font.Name = "Calibri"
    c.Font.Size = 9

    Set c = AddLabel(d, "lblCount", "Ket qua: 0", 14, 442, 250, 18, 9, False)
    Set c = AddLabel(d, "lblReadOnly", "Nguon du lieu chi duoc mo Read-Only.", 275, 442, 270, 18, 9, False)

    Set fr = d.Controls.Add("Forms.Frame.1", "fraDetail", True)
    fr.Caption = "THONG TIN VAT TU"
    fr.Left = 555
    fr.Top = 108
    fr.Width = 245
    fr.Height = 352
    fr.Font.Bold = True

    AddPair fr, "Material", "vMaterial", 16
    AddPair fr, "Description", "vDescription", 40
    AddPair fr, "Plant", "vPlant", 76
    AddPair fr, "Storage Loc.", "vSloc", 100
    AddPair fr, "UOM", "vUom", 124
    AddPair fr, "Unrestricted", "vUnrestricted", 148
    AddPair fr, "Reserved", "vReserved", 172
    AddPair fr, "Available", "vAvailable", 196
    AddPair fr, "Safety Stock", "vSafety", 220
    AddPair fr, "ROP", "vRop", 244
    AddPair fr, "Min Lot", "vMinLot", 268
    AddPair fr, "Part Number", "vPart", 292
    AddPair fr, "Manufacturer", "vMfr", 316

    Set c = AddLabel(d, "lblLocTitle", "Vi tri:", 565, 466, 45, 18, 9, True)
    Set c = AddLabel(d, "vLocation", "", 612, 466, 110, 18, 9, False)
    Set c = AddLabel(d, "lblCovTitle", "Coverage:", 565, 486, 60, 18, 9, True)
    Set c = AddLabel(d, "vCoverage", "", 628, 486, 75, 18, 9, False)
    Set c = AddLabel(d, "vStatus", "", 706, 468, 92, 34, 11, True)
End Sub

Sub AddPair(parent, labelText, valueName, y)
    Dim a, b
    Set a = AddLabel(parent, "l" & valueName, labelText, 10, y, 82, 18, 8, False)
    Set b = AddLabel(parent, valueName, "", 95, y, 135, 18, 9, True)
    b.WordWrap = True
End Sub

Function AddLabel(parent, nm, cap, x, y, w, h, fs, bold)
    Dim c
    Set c = parent.Controls.Add("Forms.Label.1", nm, True)
    c.Caption = cap
    c.Left = x
    c.Top = y
    c.Width = w
    c.Height = h
    c.Font.Name = "Calibri"
    c.Font.Size = fs
    c.Font.Bold = bold
    c.BackStyle = 0
    Set AddLabel = c
End Function

Function AddTextBox(parent, nm, x, y, w, h)
    Dim c
    Set c = parent.Controls.Add("Forms.TextBox.1", nm, True)
    c.Left = x
    c.Top = y
    c.Width = w
    c.Height = h
    c.Font.Name = "Calibri"
    c.Font.Size = 10
    Set AddTextBox = c
End Function

Function AddCombo(parent, nm, x, y, w, h)
    Dim c
    Set c = parent.Controls.Add("Forms.ComboBox.1", nm, True)
    c.Left = x
    c.Top = y
    c.Width = w
    c.Height = h
    c.Font.Name = "Calibri"
    c.Font.Size = 9
    c.Style = 2
    Set AddCombo = c
End Function

Function AddButton(parent, nm, cap, x, y, w, h)
    Dim c
    Set c = parent.Controls.Add("Forms.CommandButton.1", nm, True)
    c.Caption = cap
    c.Left = x
    c.Top = y
    c.Width = w
    c.Height = h
    c.Font.Name = "Calibri"
    c.Font.Size = 9
    Set AddButton = c
End Function

Function ReadAll(path)
    Dim ts
    Set ts = fso.OpenTextFile(path, 1, False, 0)
    ReadAll = ts.ReadAll
    ts.Close
End Function
