@echo off
setlocal
title Stock Lookup XLAM V2 - One Click Builder
cd /d "%~dp0"

echo ============================================================
echo        STOCK LOOKUP XLAM V2 - ONE CLICK BUILDER
echo ============================================================
echo.
echo Yeu cau: Windows + Microsoft Excel desktop.
echo Khong can Python, PowerShell, Node.js hay thu vien ngoai.
echo.
echo Dang tao StockLookup.xlam...
echo.

cscript //nologo "%~dp0BUILD_XLAM_ONECLICK.vbs"
set "RC=%ERRORLEVEL%"

echo.
if "%RC%"=="0" (
    echo [OK] Da tao file:
    echo      %~dp0OUTPUT\StockLookup.xlam
    echo.
    echo Ban co the chay CAI_DAT_ADDIN.bat de nap Add-in vao Excel.
) else (
    echo [LOI] Khong tao duoc XLAM. Ma loi: %RC%
    echo.
    if exist "%~dp0BUILD_ERROR.txt" (
        echo Xem chi tiet trong BUILD_ERROR.txt
        echo.
        type "%~dp0BUILD_ERROR.txt"
    )
)
echo.
pause
exit /b %RC%
