@echo off
setlocal
title Cai dat Stock Lookup Add-in
cd /d "%~dp0"

echo Dang nap StockLookup.xlam vao Excel...
echo.
cscript //nologo "%~dp0CAI_DAT_ADDIN.vbs"
set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="0" (
    echo [OK] Add-in da duoc dang ky.
) else (
    echo [LOI] Khong cai tu dong duoc. Ma loi: %RC%
)
echo.
pause
exit /b %RC%
