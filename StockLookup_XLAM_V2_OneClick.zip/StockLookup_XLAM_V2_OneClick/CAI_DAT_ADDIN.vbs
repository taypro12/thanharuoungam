Option Explicit

Dim fso, sh, root, sourcePath, addinDir, destPath
Dim xl, addin, found, a

Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")

root = fso.GetParentFolderName(WScript.ScriptFullName)
sourcePath = fso.BuildPath(fso.BuildPath(root, "OUTPUT"), "StockLookup.xlam")

If Not fso.FileExists(sourcePath) Then
    MsgBox "Chua co file OUTPUT\StockLookup.xlam." & vbCrLf & _
           "Hay chay TAO_XLAM.bat truoc.", 48, "Cai dat Stock Lookup"
    WScript.Quit 10
End If

addinDir = sh.ExpandEnvironmentStrings("%APPDATA%") & "\Microsoft\AddIns"
If Not fso.FolderExists(addinDir) Then
    On Error Resume Next
    fso.CreateFolder addinDir
    If Err.Number <> 0 Then
        MsgBox "Khong tao duoc thu muc AddIns:" & vbCrLf & addinDir & vbCrLf & _
               Err.Description, 16, "Cai dat Stock Lookup"
        WScript.Quit 20
    End If
    On Error GoTo 0
End If

destPath = fso.BuildPath(addinDir, "StockLookup.xlam")

On Error Resume Next
If fso.FileExists(destPath) Then fso.DeleteFile destPath, True
If Err.Number <> 0 Then
    MsgBox "Khong thay the duoc StockLookup.xlam cu." & vbCrLf & _
           "Hay dong Excel roi chay lai CAI_DAT_ADDIN.bat.", 48, "Cai dat Stock Lookup"
    WScript.Quit 30
End If
fso.CopyFile sourcePath, destPath, True
If Err.Number <> 0 Then
    MsgBox "Khong copy duoc Add-in vao:" & vbCrLf & destPath & vbCrLf & _
           Err.Description, 16, "Cai dat Stock Lookup"
    WScript.Quit 31
End If
Err.Clear

Set xl = CreateObject("Excel.Application")
If Err.Number <> 0 Or xl Is Nothing Then
    MsgBox "Khong mo duoc Excel.", 16, "Cai dat Stock Lookup"
    WScript.Quit 40
End If
On Error GoTo 0

xl.Visible = True
xl.DisplayAlerts = False
found = False

On Error Resume Next
For Each a In xl.AddIns
    If LCase(a.FullName) = LCase(destPath) Then
        Set addin = a
        found = True
        Exit For
    End If
Next
On Error GoTo 0

If Not found Then
    On Error Resume Next
    Set addin = xl.AddIns.Add(destPath, True)
    If Err.Number <> 0 Or addin Is Nothing Then
        MsgBox "Excel khong dang ky duoc Add-in tu dong:" & vbCrLf & _
               Err.Description & vbCrLf & vbCrLf & _
               "Ban van co the them thu cong:" & vbCrLf & _
               "File > Options > Add-ins > Excel Add-ins > Go > Browse.", _
               48, "Cai dat Stock Lookup"
        WScript.Quit 50
    End If
    On Error GoTo 0
End If

On Error Resume Next
addin.Installed = True
If Err.Number <> 0 Then
    MsgBox "Da copy file Add-in nhung Excel khong cho bat tu dong." & vbCrLf & _
           "Hay vao File > Options > Add-ins de tick StockLookup.", _
           48, "Cai dat Stock Lookup"
    WScript.Quit 51
End If
On Error GoTo 0

MsgBox "Da cai StockLookup.xlam vao Excel." & vbCrLf & vbCrLf & _
       "Tim menu 'Kho Vat Tu' trong tab Add-ins." & vbCrLf & _
       "Neu chua thay, dong va mo lai Excel.", 64, "Stock Lookup"

WScript.Quit 0
