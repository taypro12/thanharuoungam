@echo off
cscript //nologo "%~dp0CHECK_XLAM.vbs"
pause
