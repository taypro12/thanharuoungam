Option Explicit

Dim fso, root, src, outPath, xl, wb, vbProj, modComp, formComp, designer, twbComp
Set fso = CreateObject("Scripting.FileSystemObject")
root = fso.GetParentFolderName(WScript.ScriptFullName)
src = fso.BuildPath(root, "src")
outPath = fso.BuildPath(root, "StockLookup.xlam")

If Not fso.FileExists(fso.BuildPath(src, "modStockLookup.bas")) Then
    MsgBox "Thieu file src\modStockLookup.bas", 16, "Stock Lookup Builder"
    WScript.Quit 1
End If

On Error Resume Next
Set xl = CreateObject("Excel.Application")
If Err.Number <> 0 Then
    MsgBox "Khong mo duoc Microsoft Excel. May can co Excel desktop.", 16, "Stock Lookup Builder"
    WScript.Quit 2
End If
On Error GoTo 0

xl.Visible = False
xl.DisplayAlerts = False
Set wb = xl.Workbooks.Add

On Error Resume Next
Set vbProj = wb.VBProject
If Err.Number <> 0 Or vbProj Is Nothing Then
    xl.DisplayAlerts = False
    wb.Close False
    xl.Quit
    MsgBox "Excel dang chan quyen tao VBA." & vbCrLf & vbCrLf & _
           "Bat tam thoi:" & vbCrLf & _
           "Excel > File > Options > Trust Center > Trust Center Settings > Macro Settings >" & vbCrLf & _
           "Trust access to the VBA project object model." & vbCrLf & vbCrLf & _
           "Sau khi tao xong StockLookup.xlam co the tat lai tuy chon nay.", 48, "Stock Lookup Builder"
    WScript.Quit 3
End If
On Error GoTo 0

' Standard module
Set modComp = vbProj.VBComponents.Add(1)
modComp.Name = "modStockLookup"
modComp.CodeModule.AddFromString ReadAll(fso.BuildPath(src, "modStockLookup.bas"))

' UserForm
Set formComp = vbProj.VBComponents.Add(3)
formComp.Name = "frmStockLookup"
formComp.Properties("Caption") = "Tra cuu ton kho - Stock Lookup"
formComp.Properties("Width") = 835
formComp.Properties("Height") = 520
Set designer = formComp.Designer

BuildForm designer
formComp.CodeModule.AddFromString ReadAll(fso.BuildPath(src, "frmStockLookup_Code.txt"))

' ThisWorkbook events
Set twbComp = vbProj.VBComponents("ThisWorkbook")
If twbComp.CodeModule.CountOfLines > 0 Then
    twbComp.CodeModule.DeleteLines 1, twbComp.CodeModule.CountOfLines
End If
twbComp.CodeModule.AddFromString ReadAll(fso.BuildPath(src, "ThisWorkbook_Code.txt"))

' Hide workbook sheet
On Error Resume Next
wb.Worksheets(1).Name = "_ADDIN"
wb.Worksheets(1).Visible = 2
wb.IsAddin = True
On Error GoTo 0

If fso.FileExists(outPath) Then fso.DeleteFile outPath, True

On Error Resume Next
wb.SaveAs outPath, 55
If Err.Number <> 0 Then
    Dim e
    e = Err.Description
    wb.Close False
    xl.Quit
    MsgBox "Khong luu duoc XLAM: " & e, 16, "Stock Lookup Builder"
    WScript.Quit 4
End If
On Error GoTo 0

wb.Close False
xl.Quit

MsgBox "Da tao thanh cong:" & vbCrLf & outPath & vbCrLf & vbCrLf & _
       "Tiep theo: Excel > File > Options > Add-ins > Manage Excel Add-ins > Go > Browse.", 64, "Stock Lookup Builder"

Sub BuildForm(d)
    Dim c, fr

    Set c = AddLabel(d, "lblTitle", "TRA CUU TON KHO VAT TU", 14, 10, 420, 28, 18, True)
    Set c = AddLabel(d, "lblSource", "Nguon: chua chon", 14, 40, 780, 18, 9, False)

    Set c = AddTextBox(d, "txtSearch", 14, 66, 280, 24)
    Set c = AddCombo(d, "cboField", 302, 66, 120, 24)
    Set c = AddButton(d, "btnSearch", "Tim kiem", 430, 64, 72, 26)
    Set c = AddButton(d, "btnClear", "Xoa", 508, 64, 55, 26)
    Set c = AddButton(d, "btnChoose", "Chon file", 570, 64, 78, 26)
    Set c = AddButton(d, "btnReload", "Lam moi", 654, 64, 72, 26)
    Set c = AddButton(d, "btnClose", "Dong", 732, 64, 55, 26)

    Set c = AddLabel(d, "hMaterial", "Material", 14, 98, 75, 16, 8, True)
    Set c = AddLabel(d, "hDescription", "Description", 91, 98, 175, 16, 8, True)
    Set c = AddLabel(d, "hPlant", "Plant", 270, 98, 50, 16, 8, True)
    Set c = AddLabel(d, "hSloc", "SLoc", 325, 98, 55, 16, 8, True)
    Set c = AddLabel(d, "hStock", "Stock", 384, 98, 55, 16, 8, True)
    Set c = AddLabel(d, "hAvail", "Avail.", 443, 98, 55, 16, 8, True)
    Set c = AddLabel(d, "hRop", "ROP", 502, 98, 50, 16, 8, True)
    Set c = AddLabel(d, "hStatus", "Status", 556, 98, 70, 16, 8, True)

    Set c = d.Controls.Add("Forms.ListBox.1", "lstResults", True)
    c.Left = 14: c.Top = 116: c.Width = 530: c.Height = 320
    c.IntegralHeight = False
    c.Font.Name = "Calibri": c.Font.Size = 9

    Set c = AddLabel(d, "lblCount", "Ket qua: 0", 14, 442, 250, 18, 9, False)
    Set c = AddLabel(d, "lblReadOnly", "Nguon du lieu chi duoc mo Read-Only.", 275, 442, 270, 18, 9, False)

    Set fr = d.Controls.Add("Forms.Frame.1", "fraDetail", True)
    fr.Caption = "THONG TIN VAT TU"
    fr.Left = 555: fr.Top = 108: fr.Width = 245: fr.Height = 352
    fr.Font.Bold = True

    AddPair fr, "Material", "vMaterial", 16
    AddPair fr, "Description", "vDescription", 40
    AddPair fr, "Plant", "vPlant", 76
    AddPair fr, "Storage Loc.", "vSloc", 100
    AddPair fr, "UOM", "vUom", 124
    AddPair fr, "Unrestricted", "vUnrestricted", 148
    AddPair fr, "Reserved", "vReserved", 172
    AddPair fr, "Available", "vAvailable", 196
    AddPair fr, "Safety Stock", "vSafety", 220
    AddPair fr, "ROP", "vRop", 244
    AddPair fr, "Min Lot", "vMinLot", 268
    AddPair fr, "Part Number", "vPart", 292
    AddPair fr, "Manufacturer", "vMfr", 316

    Set c = AddLabel(d, "lblLocTitle", "Vi tri:", 565, 466, 45, 18, 9, True)
    Set c = AddLabel(d, "vLocation", "", 612, 466, 110, 18, 9, False)
    Set c = AddLabel(d, "lblCovTitle", "Coverage:", 565, 486, 60, 18, 9, True)
    Set c = AddLabel(d, "vCoverage", "", 628, 486, 75, 18, 9, False)
    Set c = AddLabel(d, "vStatus", "", 706, 468, 92, 34, 11, True)
End Sub

Sub AddPair(parent, labelText, valueName, y)
    Dim a, b
    Set a = AddLabel(parent, "l" & valueName, labelText, 10, y, 82, 18, 8, False)
    Set b = AddLabel(parent, valueName, "", 95, y, 135, 18, 9, True)
    b.WordWrap = True
End Sub

Function AddLabel(parent, nm, cap, x, y, w, h, fs, bold)
    Dim c
    Set c = parent.Controls.Add("Forms.Label.1", nm, True)
    c.Caption = cap
    c.Left = x: c.Top = y: c.Width = w: c.Height = h
    c.Font.Name = "Calibri": c.Font.Size = fs: c.Font.Bold = bold
    c.BackStyle = 0
    Set AddLabel = c
End Function

Function AddTextBox(parent, nm, x, y, w, h)
    Dim c
    Set c = parent.Controls.Add("Forms.TextBox.1", nm, True)
    c.Left = x: c.Top = y: c.Width = w: c.Height = h
    c.Font.Name = "Calibri": c.Font.Size = 10
    Set AddTextBox = c
End Function

Function AddCombo(parent, nm, x, y, w, h)
    Dim c
    Set c = parent.Controls.Add("Forms.ComboBox.1", nm, True)
    c.Left = x: c.Top = y: c.Width = w: c.Height = h
    c.Font.Name = "Calibri": c.Font.Size = 9
    c.Style = 2
    Set AddCombo = c
End Function

Function AddButton(parent, nm, cap, x, y, w, h)
    Dim c
    Set c = parent.Controls.Add("Forms.CommandButton.1", nm, True)
    c.Caption = cap
    c.Left = x: c.Top = y: c.Width = w: c.Height = h
    c.Font.Name = "Calibri": c.Font.Size = 9
    Set AddButton = c
End Function

Function ReadAll(path)
    Dim ts
    Set ts = fso.OpenTextFile(path, 1, False, 0)
    ReadAll = ts.ReadAll
    ts.Close
End Function
