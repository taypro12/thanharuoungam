Option Explicit
Dim xl, wb, p
On Error Resume Next
Set xl = CreateObject("Excel.Application")
If Err.Number <> 0 Then
    MsgBox "Excel desktop: KHONG MO DUOC", 16, "Check XLAM"
    WScript.Quit
End If
Set wb = xl.Workbooks.Add
Set p = wb.VBProject
If Err.Number <> 0 Or p Is Nothing Then
    MsgBox "Excel: OK" & vbCrLf & "VBA Project Access: BI CHAN" & vbCrLf & vbCrLf & _
           "Can bat Trust access to the VBA project object model de chay BUILD_XLAM.vbs.", 48, "Check XLAM"
Else
    MsgBox "Excel: OK" & vbCrLf & "VBA Project Access: OK" & vbCrLf & vbCrLf & _
           "Co the chay BUILD_XLAM.vbs.", 64, "Check XLAM"
End If
wb.Close False
xl.Quit
