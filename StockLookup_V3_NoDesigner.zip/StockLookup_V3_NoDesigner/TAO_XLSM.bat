@echo off
cd /d "%~dp0"
title Tao StockLookup.xlsm - V3 No Designer
echo Dang tao StockLookup.xlsm...
echo.
cscript //nologo "%~dp0BUILD_V3.vbs" xlsm
set RC=%ERRORLEVEL%
echo.
if not "%RC%"=="0" (
  echo [LOI] Ma loi: %RC%
  if exist "%~dp0BUILD_ERROR.txt" type "%~dp0BUILD_ERROR.txt"
) else (
  echo [OK] OUTPUT\StockLookup.xlsm
)
echo.
pause
exit /b %RC%
