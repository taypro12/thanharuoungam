Option Explicit

Public gData As Variant
Public gHeaderRow As Long
Public gMap As Object
Public gLoaded As Boolean
Public gSourcePath As String

Private Const APP_KEY As String = "StockLookupV3"
Private Const MENU_TAG As String = "StockLookupMenu"

Public Sub Auto_Open()
    On Error Resume Next
    InstallStockMenu
End Sub

Public Sub InstallStockMenu()
    Dim bar As Object, pop As Object, btn As Object
    On Error Resume Next
    RemoveStockMenu
    Set bar = Application.CommandBars("Worksheet Menu Bar")
    If bar Is Nothing Then Exit Sub

    Set pop = bar.Controls.Add(10, Temporary:=True)
    pop.Caption = "Kho Vat Tu"
    pop.Tag = MENU_TAG

    Set btn = pop.Controls.Add(1)
    btn.Caption = "Tra cuu vat tu"
    btn.OnAction = "'" & ThisWorkbook.Name & "'!OpenStockLookup"

    Set btn = pop.Controls.Add(1)
    btn.Caption = "Chon file du lieu ngoai"
    btn.OnAction = "'" & ThisWorkbook.Name & "'!ChooseSourceAndOpen"

    Set btn = pop.Controls.Add(1)
    btn.Caption = "Dung du lieu trong file nay"
    btn.OnAction = "'" & ThisWorkbook.Name & "'!UseInternalData"

    Set btn = pop.Controls.Add(1)
    btn.Caption = "Lam moi du lieu"
    btn.OnAction = "'" & ThisWorkbook.Name & "'!ReloadStockData"
End Sub

Public Sub RemoveStockMenu()
    Dim bar As Object, c As Object
    On Error Resume Next
    Set bar = Application.CommandBars("Worksheet Menu Bar")
    If bar Is Nothing Then Exit Sub
    For Each c In bar.Controls
        If c.Tag = MENU_TAG Then c.Delete
    Next c
End Sub

Public Sub OpenStockLookup()
    If Not LoadStockData(False) Then Exit Sub
    frmStockLookup.Show vbModeless
End Sub

Public Sub ChooseSourceAndOpen()
    If Not ChooseSourceFile() Then Exit Sub
    If LoadStockData(True) Then frmStockLookup.Show vbModeless
End Sub

Public Sub UseInternalData()
    gSourcePath = ""
    DeleteSetting APP_KEY, "Config"
    gLoaded = False
    If LoadStockData(True) Then
        MsgBox "Dang dung sheet STOCK_DATA trong file nay.", vbInformation, "Stock Lookup"
    End If
End Sub

Public Sub ReloadStockData()
    If LoadStockData(True) Then
        MsgBox "Da lam moi du lieu.", vbInformation, "Stock Lookup"
    End If
End Sub

Public Function GetSourcePath() As String
    If Len(gSourcePath) = 0 Then
        gSourcePath = GetSetting(APP_KEY, "Config", "SourcePath", "")
    End If
    GetSourcePath = gSourcePath
End Function

Public Function ChooseSourceFile() As Boolean
    Dim fd As Object, p As String
    On Error GoTo EH

    Set fd = Application.FileDialog(3)
    With fd
        .Title = "Chon file du lieu ton kho"
        .AllowMultiSelect = False
        .Filters.Clear
        .Filters.Add "Excel/CSV", "*.xlsx;*.xlsm;*.xls;*.csv"
        If .Show <> -1 Then Exit Function
        p = .SelectedItems(1)
    End With

    gSourcePath = p
    SaveSetting APP_KEY, "Config", "SourcePath", p
    gLoaded = False
    ChooseSourceFile = True
    Exit Function
EH:
    MsgBox "Khong chon duoc file: " & Err.Description, vbExclamation, "Stock Lookup"
End Function

Public Function LoadStockData(Optional ByVal ForceReload As Boolean = False) As Boolean
    Dim p As String
    Dim wb As Workbook, ws As Worksheet
    Dim externalWb As Boolean
    Dim arr As Variant
    Dim oldCalc As XlCalculation

    On Error GoTo EH

    If gLoaded And Not ForceReload Then
        LoadStockData = True
        Exit Function
    End If

    p = GetSourcePath()

    Application.ScreenUpdating = False
    Application.EnableEvents = False
    oldCalc = Application.Calculation
    Application.Calculation = xlCalculationManual

    If Len(p) = 0 Then
        Set wb = ThisWorkbook
        externalWb = False

        On Error Resume Next
        Set ws = wb.Worksheets("STOCK_DATA")
        On Error GoTo EH
        If ws Is Nothing Then Set ws = FindDataSheet(wb)
    Else
        If Dir(p) = "" Then
            MsgBox "Khong tim thay file nguon:" & vbCrLf & p, vbExclamation, "Stock Lookup"
            GoTo SafeExit
        End If

        Set wb = Workbooks.Open(Filename:=p, ReadOnly:=True, UpdateLinks:=0, AddToMru:=False)
        externalWb = True
        Set ws = FindDataSheet(wb)
    End If

    If ws Is Nothing Then
        MsgBox "Khong tim thay sheet co du lieu.", vbExclamation, "Stock Lookup"
        GoTo SafeExit
    End If

    arr = ws.UsedRange.Value2
    If Not IsArray(arr) Then
        MsgBox "Khong co bang du lieu hop le.", vbExclamation, "Stock Lookup"
        GoTo SafeExit
    End If

    gHeaderRow = FindHeaderRow(arr)
    If gHeaderRow = 0 Then
        MsgBox "Khong tim thay dong tieu de Material/Ma vat tu.", vbExclamation, "Stock Lookup"
        GoTo SafeExit
    End If

    Set gMap = CreateObject("Scripting.Dictionary")
    BuildHeaderMap arr, gHeaderRow, gMap

    If Not gMap.Exists("Material") Then
        MsgBox "Khong nhan dien duoc cot Material/Ma vat tu.", vbExclamation, "Stock Lookup"
        GoTo SafeExit
    End If

    gData = arr
    gLoaded = True
    LoadStockData = True

SafeExit:
    On Error Resume Next
    If externalWb Then wb.Close SaveChanges:=False
    Application.Calculation = oldCalc
    Application.EnableEvents = True
    Application.ScreenUpdating = True
    Exit Function

EH:
    MsgBox "Loi doc du lieu: " & Err.Description, vbCritical, "Stock Lookup"
    Resume SafeExit
End Function

Private Function FindDataSheet(ByVal wb As Workbook) As Worksheet
    Dim ws As Worksheet, ur As Range
    For Each ws In wb.Worksheets
        If UCase$(ws.Name) = "STOCK_DATA" Then
            Set FindDataSheet = ws
            Exit Function
        End If
    Next ws

    For Each ws In wb.Worksheets
        Set ur = Nothing
        On Error Resume Next
        Set ur = ws.UsedRange
        On Error GoTo 0
        If Not ur Is Nothing Then
            If ur.Rows.Count >= 2 And ur.Columns.Count >= 2 Then
                Set FindDataSheet = ws
                Exit Function
            End If
        End If
    Next ws
End Function

Private Function FindHeaderRow(ByVal arr As Variant) As Long
    Dim r As Long, c As Long, maxR As Long, maxC As Long
    Dim score As Long, bestScore As Long, key As String

    maxR = UBound(arr, 1)
    maxC = UBound(arr, 2)
    If maxR > 20 Then maxR = 20

    For r = 1 To maxR
        score = 0
        For c = 1 To maxC
            key = GetSemanticKey(NormalizeHeader(arr(r, c)))
            If Len(key) > 0 Then score = score + 1
        Next c

        If score > bestScore Then
            bestScore = score
            FindHeaderRow = r
        End If
    Next r

    If bestScore < 1 Then FindHeaderRow = 0
End Function

Private Sub BuildHeaderMap(ByVal arr As Variant, ByVal headerRow As Long, ByVal d As Object)
    Dim c As Long, key As String
    For c = 1 To UBound(arr, 2)
        key = GetSemanticKey(NormalizeHeader(arr(headerRow, c)))
        If Len(key) > 0 Then
            If Not d.Exists(key) Then d.Add key, c
        End If
    Next c
End Sub

Private Function GetSemanticKey(ByVal h As String) As String
    Select Case h
        Case "material", "material number", "material no", "matnr", "ma vat tu", "ma vt"
            GetSemanticKey = "Material"
        Case "material description", "description", "short text", "material short text", "mo ta", "ten vat tu", "van ban ngan"
            GetSemanticKey = "Description"
        Case "plant", "werks", "nha may"
            GetSemanticKey = "Plant"
        Case "storage location", "storage loc", "sloc", "lgort", "kho", "vi tri luu tru"
            GetSemanticKey = "StorageLocation"
        Case "base unit of measure", "base unit", "uom", "unit", "meins", "dvt", "don vi"
            GetSemanticKey = "UOM"
        Case "unrestricted", "unrestricted stock", "unrestricted use", "unrestricted use stock", "free stock", "ton khong han che"
            GetSemanticKey = "Unrestricted"
        Case "quality inspection", "quality stock", "quality inspection stock", "kiem tra chat luong"
            GetSemanticKey = "Quality"
        Case "blocked", "blocked stock", "ton bi chan"
            GetSemanticKey = "Blocked"
        Case "reserved", "reservation", "reserved stock", "ton dat truoc"
            GetSemanticKey = "Reserved"
        Case "safety stock", "ton an toan"
            GetSemanticKey = "SafetyStock"
        Case "reorder point", "rop", "diem dat hang"
            GetSemanticKey = "ROP"
        Case "min stock", "minimum stock", "ton min", "ton toi thieu"
            GetSemanticKey = "MinStock"
        Case "max stock", "maximum stock", "ton max", "ton toi da"
            GetSemanticKey = "MaxStock"
        Case "min lot", "minimum lot", "minimum lot size", "min lot size", "lo toi thieu"
            GetSemanticKey = "MinLot"
        Case "part number", "part no", "pn", "ma part"
            GetSemanticKey = "PartNumber"
        Case "manufacturer", "mfr", "hang san xuat", "nha san xuat"
            GetSemanticKey = "Manufacturer"
        Case "warehouse location", "storage bin", "bin", "rack", "vi tri kho", "ke kho"
            GetSemanticKey = "WarehouseLocation"
        Case "usage 30d", "usage 30 days", "30d usage", "tieu thu 30 ngay"
            GetSemanticKey = "Usage30D"
        Case "usage 90d", "usage 90 days", "90d usage", "tieu thu 90 ngay"
            GetSemanticKey = "Usage90D"
        Case "usage 365d", "usage 365 days", "365d usage", "tieu thu 365 ngay"
            GetSemanticKey = "Usage365D"
        Case "avg daily usage", "average daily usage", "daily usage", "su dung trung binh ngay"
            GetSemanticKey = "AvgDailyUsage"
        Case "last updated", "updated", "update time", "ngay cap nhat"
            GetSemanticKey = "LastUpdated"
    End Select
End Function

Private Function NormalizeHeader(ByVal v As Variant) As String
    Dim s As String
    On Error Resume Next

    s = LCase$(Trim$(CStr(v)))
    s = StripVietnamese(s)
    s = Replace(s, Chr$(160), " ")
    s = Replace(s, vbCr, " ")
    s = Replace(s, vbLf, " ")
    s = Replace(s, "_", " ")
    s = Replace(s, "-", " ")
    s = Replace(s, "/", " ")
    s = Replace(s, ".", " ")
    s = Replace(s, ":", " ")

    Do While InStr(s, "  ") > 0
        s = Replace(s, "  ", " ")
    Loop

    NormalizeHeader = Trim$(s)
End Function

Private Function ReplaceCodePoints(ByVal s As String, ByVal codes As String, ByVal repl As String) As String
    Dim a As Variant, x As Variant
    a = Split(codes, ",")

    For Each x In a
        If Len(x) > 0 Then s = Replace(s, ChrW(CLng("&H" & x)), repl)
    Next x

    ReplaceCodePoints = s
End Function

Private Function StripVietnamese(ByVal s As String) As String
    s = ReplaceCodePoints(s, "00E0,00E1,1EA3,00E3,1EA1,0103,1EB1,1EAF,1EB3,1EB5,1EB7,00E2,1EA7,1EA5,1EA9,1EAB,1EAD", "a")
    s = ReplaceCodePoints(s, "00E8,00E9,1EBB,1EBD,1EB9,00EA,1EC1,1EBF,1EC3,1EC5,1EC7", "e")
    s = ReplaceCodePoints(s, "00EC,00ED,1EC9,0129,1ECB", "i")
    s = ReplaceCodePoints(s, "00F2,00F3,1ECF,00F5,1ECD,00F4,1ED3,1ED1,1ED5,1ED7,1ED9,01A1,1EDD,1EDB,1EDF,1EE1,1EE3", "o")
    s = ReplaceCodePoints(s, "00F9,00FA,1EE7,0169,1EE5,01B0,1EEB,1EE9,1EED,1EEF,1EF1", "u")
    s = ReplaceCodePoints(s, "1EF3,00FD,1EF7,1EF9,1EF5", "y")
    s = ReplaceCodePoints(s, "0111,0110", "d")
    StripVietnamese = s
End Function

Public Function CellText(ByVal rowNo As Long, ByVal key As String) As String
    On Error GoTo EH
    If gMap Is Nothing Then Exit Function
    If Not gMap.Exists(key) Then Exit Function
    If IsError(gData(rowNo, gMap(key))) Then Exit Function
    CellText = Trim$(CStr(gData(rowNo, gMap(key))))
EH:
End Function

Public Function CellNumber(ByVal rowNo As Long, ByVal key As String) As Double
    Dim v As Variant
    On Error GoTo EH
    If gMap Is Nothing Then Exit Function
    If Not gMap.Exists(key) Then Exit Function
    v = gData(rowNo, gMap(key))
    If IsNumeric(v) Then CellNumber = CDbl(v)
EH:
End Function

Public Function AvailableStock(ByVal rowNo As Long) As Double
    AvailableStock = CellNumber(rowNo, "Unrestricted") - CellNumber(rowNo, "Reserved")
End Function

Public Function StockStatus(ByVal rowNo As Long) As String
    Dim stock As Double, safety As Double, rop As Double
    stock = AvailableStock(rowNo)
    safety = CellNumber(rowNo, "SafetyStock")
    rop = CellNumber(rowNo, "ROP")

    If stock <= 0 Then
        StockStatus = "HET HANG"
    ElseIf safety > 0 And stock <= safety Then
        StockStatus = "NGUY HIEM"
    ElseIf rop > 0 And stock <= rop Then
        StockStatus = "CAN DAT HANG"
    Else
        StockStatus = "AN TOAN"
    End If
End Function

Public Function CoverageText(ByVal rowNo As Long) As String
    Dim avg As Double, stock As Double
    avg = CellNumber(rowNo, "AvgDailyUsage")
    stock = AvailableStock(rowNo)

    If avg > 0 Then
        CoverageText = Format(stock / avg, "0.0") & " ngay"
    Else
        CoverageText = ""
    End If
End Function

Public Sub SearchData(ByVal lst As Object, ByVal query As String, ByVal fieldName As String)
    Dim r As Long, lastRow As Long
    Dim match As Boolean, q As String, hay As String, n As Long

    lst.Clear
    lst.ColumnCount = 9
    lst.ColumnWidths = "70 pt;180 pt;55 pt;65 pt;60 pt;60 pt;60 pt;82 pt;0 pt"

    If Not gLoaded Then Exit Sub

    q = LCase$(Trim$(query))
    lastRow = UBound(gData, 1)

    For r = gHeaderRow + 1 To lastRow
        If Len(CellText(r, "Material")) > 0 Then
            match = False

            If Len(q) = 0 Then
                match = True
            Else
                Select Case fieldName
                    Case "Material"
                        hay = LCase$(CellText(r, "Material"))
                    Case "Description"
                        hay = LCase$(CellText(r, "Description"))
                    Case "PartNumber"
                        hay = LCase$(CellText(r, "PartNumber"))
                    Case Else
                        hay = LCase$(CellText(r, "Material") & " " & _
                                     CellText(r, "Description") & " " & _
                                     CellText(r, "PartNumber") & " " & _
                                     CellText(r, "Manufacturer"))
                End Select

                match = (InStr(1, hay, q, vbTextCompare) > 0)
            End If

            If match Then
                lst.AddItem CellText(r, "Material")
                n = lst.ListCount - 1
                lst.List(n, 1) = CellText(r, "Description")
                lst.List(n, 2) = CellText(r, "Plant")
                lst.List(n, 3) = CellText(r, "StorageLocation")
                lst.List(n, 4) = Format(CellNumber(r, "Unrestricted"), "#,##0.##")
                lst.List(n, 5) = Format(AvailableStock(r), "#,##0.##")
                lst.List(n, 6) = Format(CellNumber(r, "ROP"), "#,##0.##")
                lst.List(n, 7) = StockStatus(r)
                lst.List(n, 8) = CStr(r)

                If lst.ListCount >= 500 Then Exit For
            End If
        End If
    Next r
End Sub

Public Sub ShowDetail(ByVal frm As Object, ByVal rowNo As Long)
    frm.vMaterial.Caption = CellText(rowNo, "Material")
    frm.vDescription.Caption = CellText(rowNo, "Description")
    frm.vPlant.Caption = CellText(rowNo, "Plant")
    frm.vSloc.Caption = CellText(rowNo, "StorageLocation")
    frm.vUom.Caption = CellText(rowNo, "UOM")
    frm.vUnrestricted.Caption = Format(CellNumber(rowNo, "Unrestricted"), "#,##0.##")
    frm.vReserved.Caption = Format(CellNumber(rowNo, "Reserved"), "#,##0.##")
    frm.vAvailable.Caption = Format(AvailableStock(rowNo), "#,##0.##")
    frm.vSafety.Caption = Format(CellNumber(rowNo, "SafetyStock"), "#,##0.##")
    frm.vRop.Caption = Format(CellNumber(rowNo, "ROP"), "#,##0.##")
    frm.vMinLot.Caption = Format(CellNumber(rowNo, "MinLot"), "#,##0.##")
    frm.vPart.Caption = CellText(rowNo, "PartNumber")
    frm.vMfr.Caption = CellText(rowNo, "Manufacturer")
    frm.vLocation.Caption = CellText(rowNo, "WarehouseLocation")
    frm.vCoverage.Caption = CoverageText(rowNo)
    frm.vStatus.Caption = StockStatus(rowNo)
End Sub
