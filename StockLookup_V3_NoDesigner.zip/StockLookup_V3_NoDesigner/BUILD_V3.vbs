Option Explicit

Dim fso, sh, root, src, basePath, outDir, mode, outPath, fileFormat
Dim xl, wb, vbProj, modComp, formComp, twbComp
Dim errFile, p

Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")

root = fso.GetParentFolderName(WScript.ScriptFullName)
src = fso.BuildPath(root, "src")
basePath = fso.BuildPath(root, "StockLookup_Base.xlsx")
outDir = fso.BuildPath(root, "OUTPUT")
errFile = fso.BuildPath(root, "BUILD_ERROR.txt")

If WScript.Arguments.Count < 1 Then
    mode = "xlsm"
Else
    mode = LCase(WScript.Arguments(0))
End If

If mode = "xlam" Then
    outPath = fso.BuildPath(outDir, "StockLookup.xlam")
    fileFormat = 55
Else
    outPath = fso.BuildPath(outDir, "StockLookup.xlsm")
    fileFormat = 52
End If

On Error Resume Next
If fso.FileExists(errFile) Then fso.DeleteFile errFile, True
On Error GoTo 0

If Not fso.FolderExists(outDir) Then fso.CreateFolder outDir

If Not fso.FileExists(basePath) Then
    Fail 10, "Thieu StockLookup_Base.xlsx."
End If

If Not fso.FileExists(fso.BuildPath(src, "modStockLookup.bas")) Then
    Fail 11, "Thieu src\modStockLookup.bas."
End If

If Not fso.FileExists(fso.BuildPath(src, "frmStockLookup.frm")) Then
    Fail 12, "Thieu src\frmStockLookup.frm."
End If

If Not fso.FileExists(fso.BuildPath(src, "ThisWorkbook_Code.txt")) Then
    Fail 13, "Thieu src\ThisWorkbook_Code.txt."
End If

On Error Resume Next
Set xl = CreateObject("Excel.Application")
If Err.Number <> 0 Or xl Is Nothing Then
    Fail 20, "Khong mo duoc Microsoft Excel desktop."
End If
Err.Clear
On Error GoTo 0

xl.Visible = False
xl.DisplayAlerts = False
xl.ScreenUpdating = False
xl.EnableEvents = False

On Error Resume Next
Set wb = xl.Workbooks.Open(basePath, False, False)
If Err.Number <> 0 Or wb Is Nothing Then
    FailWithExcel 21, "Khong mo duoc StockLookup_Base.xlsx: " & Err.Description
End If
Err.Clear

Set vbProj = wb.VBProject
If Err.Number <> 0 Or vbProj Is Nothing Then
    FailWithExcel 30, _
        "Excel dang chan VBA Project." & vbCrLf & vbCrLf & _
        "Tren MAY TAO FILE, bat tam thoi:" & vbCrLf & _
        "Excel > File > Options > Trust Center > Trust Center Settings > Macro Settings >" & vbCrLf & _
        "Trust access to the VBA project object model."
End If
Err.Clear
On Error GoTo 0

' Remove same-name components if rerun.
On Error Resume Next
Set p = vbProj.VBComponents("modStockLookup")
If Not p Is Nothing Then vbProj.VBComponents.Remove p
Set p = Nothing
Set p = vbProj.VBComponents("frmStockLookup")
If Not p Is Nothing Then vbProj.VBComponents.Remove p
Set p = Nothing
On Error GoTo 0

' Import standard module.
On Error Resume Next
Set modComp = vbProj.VBComponents.Import(fso.BuildPath(src, "modStockLookup.bas"))
If Err.Number <> 0 Or modComp Is Nothing Then
    FailWithExcel 40, "Khong import duoc modStockLookup.bas: " & Err.Description
End If
Err.Clear
On Error GoTo 0

' Import UserForm directly. NO .Designer usage.
On Error Resume Next
Set formComp = vbProj.VBComponents.Import(fso.BuildPath(src, "frmStockLookup.frm"))
If Err.Number <> 0 Or formComp Is Nothing Then
    FailWithExcel 50, "Khong import duoc frmStockLookup.frm: " & Err.Description
End If
Err.Clear
On Error GoTo 0

' Replace ThisWorkbook code.
On Error Resume Next
Set twbComp = vbProj.VBComponents("ThisWorkbook")
If Err.Number <> 0 Or twbComp Is Nothing Then
    FailWithExcel 60, "Khong truy cap duoc ThisWorkbook: " & Err.Description
End If
Err.Clear

If twbComp.CodeModule.CountOfLines > 0 Then
    twbComp.CodeModule.DeleteLines 1, twbComp.CodeModule.CountOfLines
End If
twbComp.CodeModule.AddFromString ReadAll(fso.BuildPath(src, "ThisWorkbook_Code.txt"))

If Err.Number <> 0 Then
    FailWithExcel 61, "Khong nap duoc ThisWorkbook code: " & Err.Description
End If
Err.Clear
On Error GoTo 0

If mode = "xlam" Then
    On Error Resume Next
    wb.IsAddin = True
    On Error GoTo 0
End If

If fso.FileExists(outPath) Then
    On Error Resume Next
    fso.DeleteFile outPath, True
    If Err.Number <> 0 Then
        FailWithExcel 70, "Khong ghi de duoc file cu. Hay dong StockLookup neu dang mo."
    End If
    Err.Clear
    On Error GoTo 0
End If

On Error Resume Next
wb.SaveAs outPath, fileFormat
If Err.Number <> 0 Then
    Dim saveErr
    saveErr = Err.Description
    Err.Clear
    FailWithExcel 71, "Khong luu duoc file: " & saveErr
End If
On Error GoTo 0

On Error Resume Next
wb.Close False
Set wb = Nothing
xl.EnableEvents = True
xl.ScreenUpdating = True
xl.Quit
Set xl = Nothing
On Error GoTo 0

If Not fso.FileExists(outPath) Then
    Fail 72, "Khong tim thay file dau ra sau khi Excel SaveAs."
End If

On Error Resume Next
sh.Run "explorer.exe /select,""" & outPath & """", 1, False
On Error GoTo 0

MsgBox "DA TAO XONG!" & vbCrLf & vbCrLf & outPath & vbCrLf & vbCrLf & _
       "Ban co the mo file va bam Enable Content neu Excel yeu cau.", _
       64, "Stock Lookup V3"

WScript.Quit 0

Function ReadAll(path)
    Dim ts
    Set ts = fso.OpenTextFile(path, 1, False, 0)
    ReadAll = ts.ReadAll
    ts.Close
End Function

Sub Fail(code, message)
    WriteError code, message
    MsgBox message & vbCrLf & vbCrLf & "Chi tiet: " & errFile, 16, "Stock Lookup V3"
    WScript.Quit code
End Sub

Sub FailWithExcel(code, message)
    On Error Resume Next
    If Not wb Is Nothing Then wb.Close False
    If Not xl Is Nothing Then
        xl.EnableEvents = True
        xl.ScreenUpdating = True
        xl.Quit
    End If
    On Error GoTo 0
    Fail code, message
End Sub

Sub WriteError(code, message)
    Dim ts
    On Error Resume Next
    Set ts = fso.CreateTextFile(errFile, True, False)
    ts.WriteLine "Stock Lookup V3 - BUILD ERROR"
    ts.WriteLine "Error code: " & code
    ts.WriteLine "Time: " & Now
    ts.WriteLine ""
    ts.WriteLine message
    ts.Close
    On Error GoTo 0
End Sub
