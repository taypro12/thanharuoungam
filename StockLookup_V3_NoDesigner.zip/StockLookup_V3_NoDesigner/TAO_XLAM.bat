@echo off
cd /d "%~dp0"
title Tao StockLookup.xlam - V3 No Designer
echo Dang tao StockLookup.xlam...
echo.
cscript //nologo "%~dp0BUILD_V3.vbs" xlam
set RC=%ERRORLEVEL%
echo.
if not "%RC%"=="0" (
  echo [LOI] Ma loi: %RC%
  if exist "%~dp0BUILD_ERROR.txt" type "%~dp0BUILD_ERROR.txt"
) else (
  echo [OK] OUTPUT\StockLookup.xlam
)
echo.
pause
exit /b %RC%
