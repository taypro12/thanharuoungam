VERSION 5.00
Begin VB.UserForm frmStockLookup
   Caption         =   "Tra cuu ton kho - Dong bo Sheet"
   ClientHeight    =   7560
   ClientLeft      =   120
   ClientTop       =   465
   ClientWidth     =   12480
   StartUpPosition =   1  'CenterOwner
   Begin MSForms.Label lblTitle
      Caption         =   "TRA CUU TON KHO VAT TU"
      Height          =   330
      Left            =   180
      TabIndex        =   0
      Top             =   120
      Width           =   4050
   End
   Begin MSForms.Label lblSource
      Caption         =   "Nguon: STOCK_DATA trong file nay"
      Height          =   255
      Left            =   180
      TabIndex        =   1
      Top             =   510
      Width           =   11700
   End
   Begin MSForms.TextBox txtSearch
      Height          =   330
      Left            =   180
      TabIndex        =   2
      Top             =   930
      Width           =   4200
   End
   Begin MSForms.ComboBox cboField
      Height          =   330
      Left            =   4500
      Style           =   2
      TabIndex        =   3
      Top             =   930
      Width           =   1710
   End
   Begin MSForms.CommandButton btnSearch
      Caption         =   "Tim kiem"
      Height          =   360
      Left            =   6300
      TabIndex        =   4
      Top             =   900
      Width           =   1110
   End
   Begin MSForms.CommandButton btnClear
      Caption         =   "Xoa"
      Height          =   360
      Left            =   7470
      TabIndex        =   5
      Top             =   900
      Width           =   780
   End
   Begin MSForms.CommandButton btnChoose
      Caption         =   "Chon file"
      Height          =   360
      Left            =   8310
      TabIndex        =   6
      Top             =   900
      Width           =   1200
   End
   Begin MSForms.CommandButton btnReload
      Caption         =   "Lam moi"
      Height          =   360
      Left            =   9570
      TabIndex        =   7
      Top             =   900
      Width           =   1110
   End
   Begin MSForms.CommandButton btnClose
      Caption         =   "Dong"
      Height          =   360
      Left            =   10740
      TabIndex        =   8
      Top             =   900
      Width           =   900
   End
   Begin MSForms.Label hMaterial
      Caption         =   "Material"
      Height          =   225
      Left            =   180
      TabIndex        =   9
      Top             =   1350
      Width           =   1050
   End
   Begin MSForms.Label hDescription
      Caption         =   "Description"
      Height          =   225
      Left            =   1260
      TabIndex        =   10
      Top             =   1350
      Width           =   2700
   End
   Begin MSForms.Label hPlant
      Caption         =   "Plant"
      Height          =   225
      Left            =   3990
      TabIndex        =   11
      Top             =   1350
      Width           =   750
   End
   Begin MSForms.Label hSloc
      Caption         =   "SLoc"
      Height          =   225
      Left            =   4770
      TabIndex        =   12
      Top             =   1350
      Width           =   750
   End
   Begin MSForms.Label hStock
      Caption         =   "Stock"
      Height          =   225
      Left            =   5550
      TabIndex        =   13
      Top             =   1350
      Width           =   720
   End
   Begin MSForms.Label hAvail
      Caption         =   "Avail."
      Height          =   225
      Left            =   6300
      TabIndex        =   14
      Top             =   1350
      Width           =   720
   End
   Begin MSForms.Label hRop
      Caption         =   "ROP"
      Height          =   225
      Left            =   7050
      TabIndex        =   15
      Top             =   1350
      Width           =   690
   End
   Begin MSForms.Label hStatus
      Caption         =   "Status"
      Height          =   225
      Left            =   7770
      TabIndex        =   16
      Top             =   1350
      Width           =   960
   End
   Begin MSForms.ListBox lstResults
      ColumnCount     =   9
      Height          =   4800
      IntegralHeight  =   0   'False
      Left            =   180
      TabIndex        =   17
      Top             =   1590
      Width           =   8010
   End
   Begin MSForms.Label lblCount
      Caption         =   "Ket qua: 0"
      Height          =   255
      Left            =   180
      TabIndex        =   18
      Top             =   6480
      Width           =   2400
   End
   Begin MSForms.Label lblDetailTitle
      Caption         =   "THONG TIN VAT TU"
      Height          =   255
      Left            =   8430
      TabIndex        =   19
      Top             =   1410
      Width           =   2460
   End
   Begin MSForms.Label lMaterial
      Caption         =   "Material"
      Height          =   225
      Left            =   8430
      TabIndex        =   20
      Top             =   1770
      Width           =   1200
   End
   Begin MSForms.Label vMaterial
      Caption         =   ""
      Height          =   225
      Left            =   9630
      TabIndex        =   21
      Top             =   1770
      Width           =   2460
   End
   Begin MSForms.Label lDescription
      Caption         =   "Description"
      Height          =   225
      Left            =   8430
      TabIndex        =   22
      Top             =   2070
      Width           =   1200
   End
   Begin MSForms.Label vDescription
      Caption         =   ""
      Height          =   450
      Left            =   9630
      TabIndex        =   23
      Top             =   2070
      Width           =   2460
      WordWrap        =   -1  'True
   End
   Begin MSForms.Label lPlant
      Caption         =   "Plant"
      Height          =   225
      Left            =   8430
      TabIndex        =   24
      Top             =   2610
      Width           =   1200
   End
   Begin MSForms.Label vPlant
      Caption         =   ""
      Height          =   225
      Left            =   9630
      TabIndex        =   25
      Top             =   2610
      Width           =   2460
   End
   Begin MSForms.Label lSloc
      Caption         =   "Storage Loc."
      Height          =   225
      Left            =   8430
      TabIndex        =   26
      Top             =   2910
      Width           =   1200
   End
   Begin MSForms.Label vSloc
      Caption         =   ""
      Height          =   225
      Left            =   9630
      TabIndex        =   27
      Top             =   2910
      Width           =   2460
   End
   Begin MSForms.Label lUom
      Caption         =   "UOM"
      Height          =   225
      Left            =   8430
      TabIndex        =   28
      Top             =   3210
      Width           =   1200
   End
   Begin MSForms.Label vUom
      Caption         =   ""
      Height          =   225
      Left            =   9630
      TabIndex        =   29
      Top             =   3210
      Width           =   2460
   End
   Begin MSForms.Label lUnrestricted
      Caption         =   "Unrestricted"
      Height          =   225
      Left            =   8430
      TabIndex        =   30
      Top             =   3510
      Width           =   1200
   End
   Begin MSForms.Label vUnrestricted
      Caption         =   ""
      Height          =   225
      Left            =   9630
      TabIndex        =   31
      Top             =   3510
      Width           =   2460
   End
   Begin MSForms.Label lReserved
      Caption         =   "Reserved"
      Height          =   225
      Left            =   8430
      TabIndex        =   32
      Top             =   3810
      Width           =   1200
   End
   Begin MSForms.Label vReserved
      Caption         =   ""
      Height          =   225
      Left            =   9630
      TabIndex        =   33
      Top             =   3810
      Width           =   2460
   End
   Begin MSForms.Label lAvailable
      Caption         =   "Available"
      Height          =   225
      Left            =   8430
      TabIndex        =   34
      Top             =   4110
      Width           =   1200
   End
   Begin MSForms.Label vAvailable
      Caption         =   ""
      Height          =   225
      Left            =   9630
      TabIndex        =   35
      Top             =   4110
      Width           =   2460
   End
   Begin MSForms.Label lSafety
      Caption         =   "Safety Stock"
      Height          =   225
      Left            =   8430
      TabIndex        =   36
      Top             =   4410
      Width           =   1200
   End
   Begin MSForms.Label vSafety
      Caption         =   ""
      Height          =   225
      Left            =   9630
      TabIndex        =   37
      Top             =   4410
      Width           =   2460
   End
   Begin MSForms.Label lRop
      Caption         =   "ROP"
      Height          =   225
      Left            =   8430
      TabIndex        =   38
      Top             =   4710
      Width           =   1200
   End
   Begin MSForms.Label vRop
      Caption         =   ""
      Height          =   225
      Left            =   9630
      TabIndex        =   39
      Top             =   4710
      Width           =   2460
   End
   Begin MSForms.Label lMinLot
      Caption         =   "Min Lot"
      Height          =   225
      Left            =   8430
      TabIndex        =   40
      Top             =   5010
      Width           =   1200
   End
   Begin MSForms.Label vMinLot
      Caption         =   ""
      Height          =   225
      Left            =   9630
      TabIndex        =   41
      Top             =   5010
      Width           =   2460
   End
   Begin MSForms.Label lPart
      Caption         =   "Part Number"
      Height          =   225
      Left            =   8430
      TabIndex        =   42
      Top             =   5310
      Width           =   1200
   End
   Begin MSForms.Label vPart
      Caption         =   ""
      Height          =   225
      Left            =   9630
      TabIndex        =   43
      Top             =   5310
      Width           =   2460
   End
   Begin MSForms.Label lMfr
      Caption         =   "Manufacturer"
      Height          =   225
      Left            =   8430
      TabIndex        =   44
      Top             =   5610
      Width           =   1200
   End
   Begin MSForms.Label vMfr
      Caption         =   ""
      Height          =   225
      Left            =   9630
      TabIndex        =   45
      Top             =   5610
      Width           =   2460
   End
   Begin MSForms.Label lLocation
      Caption         =   "Vi tri"
      Height          =   225
      Left            =   8430
      TabIndex        =   46
      Top             =   5910
      Width           =   1200
   End
   Begin MSForms.Label vLocation
      Caption         =   ""
      Height          =   225
      Left            =   9630
      TabIndex        =   47
      Top             =   5910
      Width           =   2460
   End
   Begin MSForms.Label lCoverage
      Caption         =   "Coverage"
      Height          =   225
      Left            =   8430
      TabIndex        =   48
      Top             =   6210
      Width           =   1200
   End
   Begin MSForms.Label vCoverage
      Caption         =   ""
      Height          =   225
      Left            =   9630
      TabIndex        =   49
      Top             =   6210
      Width           =   2460
   End
   Begin MSForms.Label lStatus
      Caption         =   "Status"
      Height          =   225
      Left            =   8430
      TabIndex        =   50
      Top             =   6570
      Width           =   1200
   End
   Begin MSForms.Label vStatus
      Caption         =   ""
      Height          =   420
      Left            =   9630
      TabIndex        =   51
      Top             =   6510
      Width           =   2460
   End
End
Attribute VB_Name = "frmStockLookup"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub UserForm_Initialize()
    cboField.Clear
    cboField.AddItem "Tat ca"
    cboField.AddItem "Material"
    cboField.AddItem "Description"
    cboField.AddItem "Part Number"
    cboField.ListIndex = 0

    UpdateSourceCaption
    RefreshResults
End Sub

Private Sub btnSearch_Click()
    RefreshResults
End Sub

Private Sub btnClear_Click()
    txtSearch.Text = ""
    cboField.ListIndex = 0
    RefreshResults
End Sub

Private Sub btnChoose_Click()
    If ChooseSourceFile() Then
        If LoadStockData(True) Then
            UpdateSourceCaption
            RefreshResults
        End If
    End If
End Sub

Private Sub btnReload_Click()
    If LoadStockData(True) Then
        UpdateSourceCaption
        RefreshResults
    End If
End Sub

Private Sub btnClose_Click()
    Unload Me
End Sub

Private Sub txtSearch_KeyDown(ByVal KeyCode As MSForms.ReturnInteger, ByVal Shift As Integer)
    If KeyCode = 13 Then RefreshResults
End Sub

Private Sub lstResults_Click()
    Dim r As Long

    If lstResults.ListIndex < 0 Then Exit Sub

    r = CLng(lstResults.List(lstResults.ListIndex, 8))
    ShowDetail Me, r
End Sub

Private Sub lstResults_DblClick(ByVal Cancel As MSForms.ReturnBoolean)
    lstResults_Click
End Sub

Private Sub RefreshResults()
    Dim f As String

    If Not gLoaded Then
        If Not LoadStockData(False) Then Exit Sub
    End If

    Select Case cboField.ListIndex
        Case 1: f = "Material"
        Case 2: f = "Description"
        Case 3: f = "PartNumber"
        Case Else: f = "All"
    End Select

    SearchData lstResults, txtSearch.Text, f

    lblCount.Caption = "Ket qua: " & lstResults.ListCount
    If lstResults.ListCount >= 500 Then lblCount.Caption = lblCount.Caption & " (gioi han 500)"

    If lstResults.ListCount > 0 Then
        lstResults.ListIndex = 0
        lstResults_Click
    End If
End Sub

Private Sub UpdateSourceCaption()
    Dim p As String
    p = GetSourcePath()

    If Len(p) = 0 Then
        lblSource.Caption = "Nguon: STOCK_DATA trong file nay"
    Else
        lblSource.Caption = "Nguon: " & p
    End If
End Sub
