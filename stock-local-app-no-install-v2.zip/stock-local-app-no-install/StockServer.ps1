Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$ConfigPath = Join-Path $ScriptRoot 'config.json'
$FrontendRoot = Join-Path $ScriptRoot 'frontend'
$StateRoot = Join-Path $ScriptRoot 'data\state'
$MaterialsPath = Join-Path $StateRoot 'materials.json'
$MovementsPath = Join-Path $StateRoot 'movements.json'
$MetaPath = Join-Path $StateRoot 'meta.json'

function Read-JsonFile([string]$Path, $DefaultValue) {
    if (-not (Test-Path -LiteralPath $Path)) { return $DefaultValue }
    try {
        $raw = Get-Content -LiteralPath $Path -Raw -Encoding UTF8
        if ([string]::IsNullOrWhiteSpace($raw)) { return $DefaultValue }
        return ($raw | ConvertFrom-Json)
    } catch { return $DefaultValue }
}

if (-not (Test-Path -LiteralPath $ConfigPath)) { throw "Khong tim thay config.json" }
$Config = Read-JsonFile $ConfigPath $null
if ($null -eq $Config) { throw "config.json khong hop le" }

function Resolve-AppPath([string]$PathValue) {
    if ([System.IO.Path]::IsPathRooted($PathValue)) { return $PathValue }
    return [System.IO.Path]::GetFullPath((Join-Path $ScriptRoot $PathValue))
}

$ImportFolder = Resolve-AppPath ([string]$Config.import_folder)
$Port = [int]$Config.port
$LanMode = [bool]$Config.lan_mode
$SafetyDays = [double]$Config.default_safety_days
$LeadTimeDays = [double]$Config.default_lead_time_days
$ReviewDays = [double]$Config.default_review_days
$OpenBrowser = [bool]$Config.open_browser_on_start

New-Item -ItemType Directory -Force -Path $StateRoot | Out-Null
New-Item -ItemType Directory -Force -Path $ImportFolder | Out-Null

$script:Materials = @()
$script:Movements = @()
$script:Meta = [ordered]@{
    mb51_hash = ''
    mb52_hash = ''
    latest_import = $null
}

function Load-State {
    $m = Read-JsonFile $MaterialsPath @()
    $mv = Read-JsonFile $MovementsPath @()
    $meta = Read-JsonFile $MetaPath $null
    $script:Materials = @($m)
    $script:Movements = @($mv)
    if ($null -ne $meta) { $script:Meta = $meta }
}

function Save-Utf8NoBom([string]$Path, [string]$Text) {
    $enc = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($Path, $Text, $enc)
}

function Save-State {
    Save-Utf8NoBom $MaterialsPath (($script:Materials | ConvertTo-Json -Depth 8))
    Save-Utf8NoBom $MovementsPath (($script:Movements | ConvertTo-Json -Depth 8))
    Save-Utf8NoBom $MetaPath (($script:Meta | ConvertTo-Json -Depth 8))
}

function Normalize-Text([object]$Value) {
    if ($null -eq $Value) { return '' }
    $s = ([string]$Value).Trim().ToLowerInvariant()
    # Normalize Vietnamese d-stroke without requiring non-ASCII source text.
    $s = $s.Replace([char]0x0111, [char]0x0064)
    if ($s.Length -eq 0) { return '' }
    $d = $s.Normalize([Text.NormalizationForm]::FormD)
    $sb = New-Object Text.StringBuilder
    foreach ($ch in $d.ToCharArray()) {
        $cat = [Globalization.CharUnicodeInfo]::GetUnicodeCategory($ch)
        if ($cat -ne [Globalization.UnicodeCategory]::NonSpacingMark) { [void]$sb.Append($ch) }
    }
    $s = $sb.ToString().Normalize([Text.NormalizationForm]::FormC)
    return ([regex]::Replace($s, '[^a-z0-9]+', ''))
}

function To-Text([object]$Value) {
    if ($null -eq $Value) { return '' }
    if ($Value -is [double] -or $Value -is [decimal] -or $Value -is [int] -or $Value -is [long]) {
        $d = [double]$Value
        if ([Math]::Abs($d - [Math]::Round($d)) -lt 0.0000001) { return ([string][long][Math]::Round($d)) }
    }
    return ([string]$Value).Trim()
}

function To-Number([object]$Value) {
    if ($null -eq $Value) { return 0.0 }
    if ($Value -is [double] -or $Value -is [decimal] -or $Value -is [int] -or $Value -is [long]) { return [double]$Value }
    $s = ([string]$Value).Trim()
    if ($s -eq '') { return 0.0 }
    $n = 0.0
    if ([double]::TryParse($s, [Globalization.NumberStyles]::Any, [Globalization.CultureInfo]::InvariantCulture, [ref]$n)) { return $n }
    if ([double]::TryParse($s, [Globalization.NumberStyles]::Any, [Globalization.CultureInfo]::CurrentCulture, [ref]$n)) { return $n }
    $s2 = $s.Replace('.', '').Replace(',', '.')
    if ([double]::TryParse($s2, [Globalization.NumberStyles]::Any, [Globalization.CultureInfo]::InvariantCulture, [ref]$n)) { return $n }
    return 0.0
}

function To-DateIso([object]$Value) {
    if ($null -eq $Value) { return '' }
    try {
        if ($Value -is [double] -or $Value -is [decimal] -or $Value -is [int]) {
            return ([DateTime]::FromOADate([double]$Value)).ToString('yyyy-MM-dd')
        }
        if ($Value -is [DateTime]) { return ([DateTime]$Value).ToString('yyyy-MM-dd') }
        $s = ([string]$Value).Trim()
        $dt = [DateTime]::MinValue
        $formats = @('dd.MM.yyyy','dd/MM/yyyy','d/M/yyyy','MM/dd/yyyy','yyyy-MM-dd','dd-MM-yyyy')
        foreach ($f in $formats) {
            if ([DateTime]::TryParseExact($s, $f, [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::None, [ref]$dt)) { return $dt.ToString('yyyy-MM-dd') }
        }
        if ([DateTime]::TryParse($s, [ref]$dt)) { return $dt.ToString('yyyy-MM-dd') }
    } catch {}
    return ''
}

function Find-Column($Headers, [string[]]$Aliases) {
    for ($i = 0; $i -lt $Headers.Count; $i++) {
        $h = Normalize-Text $Headers[$i]
        foreach ($a in $Aliases) {
            if ($h -eq (Normalize-Text $a)) { return ($i + 1) }
        }
    }
    return 0
}

function Find-HeaderRow($Values, [int]$Rows, [int]$Cols, [string[]]$MaterialAliases) {
    $maxRow = [Math]::Min(20, $Rows)
    for ($r = 1; $r -le $maxRow; $r++) {
        $headers = @()
        for ($c = 1; $c -le $Cols; $c++) { $headers += (To-Text $Values[$r,$c]) }
        if ((Find-Column $headers $MaterialAliases) -gt 0) { return $r }
    }
    return 1
}

function Get-ExcelTable([string]$Path) {
    $excel = $null; $wb = $null; $ws = $null; $used = $null
    try {
        $excel = New-Object -ComObject Excel.Application
        $excel.Visible = $false
        $excel.DisplayAlerts = $false
        $wb = $excel.Workbooks.Open($Path, 0, $true)
        $ws = $wb.Worksheets.Item(1)
        $used = $ws.UsedRange
        $rows = [int]$used.Rows.Count
        $cols = [int]$used.Columns.Count
        $values = $used.Value2
        return [pscustomobject]@{ Values = $values; Rows = $rows; Cols = $cols }
    } finally {
        if ($null -ne $wb) { try { $wb.Close($false) } catch {} }
        if ($null -ne $excel) { try { $excel.Quit() } catch {} }
        foreach ($o in @($used,$ws,$wb,$excel)) { if ($null -ne $o) { try { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($o) } catch {} } }
        [GC]::Collect(); [GC]::WaitForPendingFinalizers()
    }
}

$MaterialAliases = @('Material','Material Number','Ma vat tu','Vat tu')
$DescriptionAliases = @('Material Description','Description','Short Text','Material Description.','Mo ta')
$PlantAliases = @('Plant','Plnt','Nha may')
$SlocAliases = @('Storage Location','SLoc','Stor. Loc.','Storage location','Kho')
$UomAliases = @('Base Unit of Measure','Base Unit','BUn','UoM','Unit','DVT')
$UnrestrictedAliases = @('Unrestricted','Unrestricted-use stock','Unrestricted Use','Unrest.','Unrestricted stock')
$ReservedAliases = @('Reserved','Reserved stock','Reservations')
$QualityAliases = @('Stock in Quality Insp.','Quality Inspection','Quality','Quality Inspection Stock')
$BlockedAliases = @('Blocked','Blocked Stock')
$PostingDateAliases = @('Posting Date','Pstng Date','Ngay hach toan')
$MovementTypeAliases = @('Movement Type','MvT','Mvt Type','Loai chuyen dong')
$QuantityAliases = @('Quantity','Qty','Qty in Un. of Entry','Quantity in UnE','So luong')
$DocumentAliases = @('Material Document','Mat. Doc.','Document','Chung tu')

function Import-MB52([string]$Path) {
    $t = Get-ExcelTable $Path
    $headerRow = Find-HeaderRow $t.Values $t.Rows $t.Cols $MaterialAliases
    $headers = @(); for ($c=1; $c -le $t.Cols; $c++) { $headers += (To-Text $t.Values[$headerRow,$c]) }
    $cMat = Find-Column $headers $MaterialAliases
    if ($cMat -eq 0) { throw "MB52: khong tim thay cot Material" }
    $cDesc = Find-Column $headers $DescriptionAliases
    $cPlant = Find-Column $headers $PlantAliases
    $cSloc = Find-Column $headers $SlocAliases
    $cUom = Find-Column $headers $UomAliases
    $cUnr = Find-Column $headers $UnrestrictedAliases
    $cRes = Find-Column $headers $ReservedAliases
    $cQual = Find-Column $headers $QualityAliases
    $cBlock = Find-Column $headers $BlockedAliases

    $map = @{}
    for ($r=$headerRow+1; $r -le $t.Rows; $r++) {
        $mat = To-Text $t.Values[$r,$cMat]
        if ([string]::IsNullOrWhiteSpace($mat)) { continue }
        if (-not $map.ContainsKey($mat)) {
            $map[$mat] = [ordered]@{
                material=$mat; description=''; plant=''; sloc=''; uom=''; part_number='';
                unrestricted=0.0; reserved=0.0; quality=0.0; blocked=0.0;
                available=0.0; usage_30d=0.0; usage_90d=0.0; usage_365d=0.0;
                avg_daily_usage=0.0; safety_stock=0.0; rop=0.0; min_stock=0.0; max_stock=0.0;
                coverage_days=$null; estimated_stockout_date=$null; status='UNKNOWN'; updated_at=''
            }
        }
        $x = $map[$mat]
        if ($cDesc -gt 0 -and [string]::IsNullOrWhiteSpace([string]$x.description)) { $x.description = To-Text $t.Values[$r,$cDesc] }
        if ($cPlant -gt 0 -and [string]::IsNullOrWhiteSpace([string]$x.plant)) { $x.plant = To-Text $t.Values[$r,$cPlant] }
        if ($cSloc -gt 0 -and [string]::IsNullOrWhiteSpace([string]$x.sloc)) { $x.sloc = To-Text $t.Values[$r,$cSloc] }
        if ($cUom -gt 0 -and [string]::IsNullOrWhiteSpace([string]$x.uom)) { $x.uom = To-Text $t.Values[$r,$cUom] }
        if ($cUnr -gt 0) { $x.unrestricted += (To-Number $t.Values[$r,$cUnr]) }
        if ($cRes -gt 0) { $x.reserved += (To-Number $t.Values[$r,$cRes]) }
        if ($cQual -gt 0) { $x.quality += (To-Number $t.Values[$r,$cQual]) }
        if ($cBlock -gt 0) { $x.blocked += (To-Number $t.Values[$r,$cBlock]) }
    }
    return @($map.Values | ForEach-Object { [pscustomobject]$_ } | Sort-Object material)
}

function Import-MB51([string]$Path) {
    $t = Get-ExcelTable $Path
    $headerRow = Find-HeaderRow $t.Values $t.Rows $t.Cols $MaterialAliases
    $headers = @(); for ($c=1; $c -le $t.Cols; $c++) { $headers += (To-Text $t.Values[$headerRow,$c]) }
    $cMat = Find-Column $headers $MaterialAliases
    if ($cMat -eq 0) { throw "MB51: khong tim thay cot Material" }
    $cDesc = Find-Column $headers $DescriptionAliases
    $cDate = Find-Column $headers $PostingDateAliases
    $cMvt = Find-Column $headers $MovementTypeAliases
    $cQty = Find-Column $headers $QuantityAliases
    $cDoc = Find-Column $headers $DocumentAliases
    $cPlant = Find-Column $headers $PlantAliases
    $cSloc = Find-Column $headers $SlocAliases
    $items = @()
    for ($r=$headerRow+1; $r -le $t.Rows; $r++) {
        $mat = To-Text $t.Values[$r,$cMat]
        if ([string]::IsNullOrWhiteSpace($mat)) { continue }
        $items += [pscustomobject][ordered]@{
            material=$mat
            description=$(if($cDesc -gt 0){To-Text $t.Values[$r,$cDesc]}else{''})
            posting_date=$(if($cDate -gt 0){To-DateIso $t.Values[$r,$cDate]}else{''})
            movement_type=$(if($cMvt -gt 0){To-Text $t.Values[$r,$cMvt]}else{''})
            quantity=$(if($cQty -gt 0){To-Number $t.Values[$r,$cQty]}else{0.0})
            document=$(if($cDoc -gt 0){To-Text $t.Values[$r,$cDoc]}else{''})
            plant=$(if($cPlant -gt 0){To-Text $t.Values[$r,$cPlant]}else{''})
            sloc=$(if($cSloc -gt 0){To-Text $t.Values[$r,$cSloc]}else{''})
        }
    }
    return @($items)
}

$ConsumptionTypes = @('201','221','261','281','291','541','551','601','643')
$ReversalTypes = @('202','222','262','282','292','542','552','602','644')

function Get-UsageForMaterial([string]$Material, [int]$Days) {
    $from = [DateTime]::Today.AddDays(-$Days)
    $sum = 0.0
    foreach ($mv in $script:Movements) {
        if ([string]$mv.material -ne $Material) { continue }
        $date = [DateTime]::MinValue
        if (-not [DateTime]::TryParse([string]$mv.posting_date, [ref]$date)) { continue }
        if ($date -lt $from -or $date -gt [DateTime]::Today.AddDays(1)) { continue }
        $qty = [double]$mv.quantity
        $mt = [string]$mv.movement_type
        if ($ReversalTypes -contains $mt) { $sum -= [Math]::Abs($qty) }
        elseif (($ConsumptionTypes -contains $mt) -or $qty -lt 0) { $sum += [Math]::Abs($qty) }
    }
    if ($sum -lt 0) { $sum = 0 }
    return $sum
}

function Recalculate-Metrics {
    $now = Get-Date
    foreach ($m in $script:Materials) {
        $available = [double]$m.unrestricted - [double]$m.reserved
        $u30 = Get-UsageForMaterial ([string]$m.material) 30
        $u90 = Get-UsageForMaterial ([string]$m.material) 90
        $u365 = Get-UsageForMaterial ([string]$m.material) 365
        $avg = 0.0
        if ($u90 -gt 0) { $avg = $u90 / 90.0 } elseif ($u365 -gt 0) { $avg = $u365 / 365.0 }
        $safety = $avg * $SafetyDays
        $rop = $avg * ($LeadTimeDays + $SafetyDays)
        $max = $avg * ($LeadTimeDays + $SafetyDays + $ReviewDays)
        $coverage = $null; $stockout = $null
        if ($avg -gt 0 -and $available -ge 0) {
            $coverage = [Math]::Round($available / $avg, 0)
            $stockout = ([DateTime]::Today.AddDays([double]$coverage)).ToString('yyyy-MM-dd')
        }
        $status = 'UNKNOWN'
        if ($available -le 0) { $status = 'OUT_OF_STOCK' }
        elseif ($avg -le 0) { $status = 'SAFE' }
        elseif ($available -le $safety) { $status = 'CRITICAL' }
        elseif ($available -le $rop) { $status = 'WATCH' }
        else { $status = 'SAFE' }
        $m.available = [Math]::Round($available,3)
        $m.usage_30d = [Math]::Round($u30,3)
        $m.usage_90d = [Math]::Round($u90,3)
        $m.usage_365d = [Math]::Round($u365,3)
        $m.avg_daily_usage = [Math]::Round($avg,4)
        $m.safety_stock = [Math]::Round($safety,3)
        $m.rop = [Math]::Round($rop,3)
        $m.min_stock = [Math]::Round($safety,3)
        $m.max_stock = [Math]::Round($max,3)
        $m.coverage_days = $coverage
        $m.estimated_stockout_date = $stockout
        $m.status = $status
        $m.updated_at = $now.ToString('yyyy-MM-ddTHH:mm:ss')
    }
}

function Get-NewestSapFile([string]$Kind) {
    $files = @(Get-ChildItem -LiteralPath $ImportFolder -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -match $Kind -and $_.Extension -match '^\.(xlsx|xlsm|xls)$' } | Sort-Object LastWriteTime -Descending)
    if ($files.Count -eq 0) { return $null }
    return $files[0]
}

function Invoke-Sync {
    $results = @(); $errors = @()
    $mb52 = Get-NewestSapFile 'MB52'
    $mb51 = Get-NewestSapFile 'MB51'
    if ($null -eq $mb52) { $errors += 'Khong tim thay file MB52*.xlsx trong thu muc import.' }
    if ($null -eq $mb51) { $errors += 'Khong tim thay file MB51*.xlsx trong thu muc import.' }

    if ($null -ne $mb52) {
        try {
            $hash = (Get-FileHash -Algorithm SHA256 -LiteralPath $mb52.FullName).Hash
            $same = ([string]$script:Meta.mb52_hash -eq $hash -and $script:Materials.Count -gt 0)
            if (-not $same) {
                $script:Materials = @(Import-MB52 $mb52.FullName)
                $script:Meta.mb52_hash = $hash
                $results += [pscustomobject]@{ file=$mb52.Name; type='MB52'; skipped=$false; rows=$script:Materials.Count }
            } else { $results += [pscustomobject]@{ file=$mb52.Name; type='MB52'; skipped=$true; rows=$script:Materials.Count } }
        } catch { $errors += ('MB52: ' + $_.Exception.Message) }
    }

    if ($null -ne $mb51) {
        try {
            $hash = (Get-FileHash -Algorithm SHA256 -LiteralPath $mb51.FullName).Hash
            $same = ([string]$script:Meta.mb51_hash -eq $hash -and $script:Movements.Count -gt 0)
            if (-not $same) {
                $script:Movements = @(Import-MB51 $mb51.FullName)
                $script:Meta.mb51_hash = $hash
                $results += [pscustomobject]@{ file=$mb51.Name; type='MB51'; skipped=$false; rows=$script:Movements.Count }
            } else { $results += [pscustomobject]@{ file=$mb51.Name; type='MB51'; skipped=$true; rows=$script:Movements.Count } }
        } catch { $errors += ('MB51: ' + $_.Exception.Message) }
    }

    if ($script:Materials.Count -gt 0) {
        Recalculate-Metrics
        $latestName = if ($null -ne $mb52) { $mb52.Name } elseif ($null -ne $mb51) { $mb51.Name } else { '' }
        $script:Meta.latest_import = [pscustomobject]@{ file_name=$latestName; imported_at=(Get-Date).ToString('yyyy-MM-ddTHH:mm:ss') }
        Save-State
    }
    return [pscustomobject]@{ results=$results; errors=$errors }
}

function Get-QueryParams([string]$Target) {
    $h = @{}
    $qpos = $Target.IndexOf('?')
    if ($qpos -lt 0) { return $h }
    $qs = $Target.Substring($qpos + 1)
    foreach ($part in $qs.Split('&')) {
        if ([string]::IsNullOrWhiteSpace($part)) { continue }
        $kv = $part.Split('=',2)
        $k = [Uri]::UnescapeDataString($kv[0].Replace('+',' '))
        $v = if ($kv.Count -gt 1) { [Uri]::UnescapeDataString($kv[1].Replace('+',' ')) } else { '' }
        $h[$k] = $v
    }
    return $h
}

function Get-PathOnly([string]$Target) {
    $q = $Target.IndexOf('?')
    if ($q -ge 0) { return $Target.Substring(0,$q) }
    return $Target
}

function Get-Dashboard {
    $safe = @($script:Materials | Where-Object { $_.status -eq 'SAFE' }).Count
    $watch = @($script:Materials | Where-Object { $_.status -eq 'WATCH' }).Count
    $critical = @($script:Materials | Where-Object { $_.status -eq 'CRITICAL' }).Count
    $out = @($script:Materials | Where-Object { $_.status -eq 'OUT_OF_STOCK' }).Count
    $attention = @($script:Materials | Where-Object { $_.status -in @('OUT_OF_STOCK','CRITICAL','WATCH') } | Sort-Object @{Expression={switch($_.status){'OUT_OF_STOCK'{0};'CRITICAL'{1};'WATCH'{2};default{9}}}}, @{Expression={if($null -eq $_.coverage_days){999999}else{[double]$_.coverage_days}}} | Select-Object -First 12)
    return [pscustomobject]@{ total=$script:Materials.Count; safe=$safe; watch=$watch; critical=$critical; out_of_stock=$out; critical_items=$attention; latest_import=$script:Meta.latest_import }
}

function Json-Bytes($Object) {
    $json = $Object | ConvertTo-Json -Depth 10 -Compress
    $enc = New-Object System.Text.UTF8Encoding($false)
    return $enc.GetBytes($json)
}

function Text-Bytes([string]$Text) {
    $enc = New-Object System.Text.UTF8Encoding($false)
    return $enc.GetBytes($Text)
}

function Write-HttpResponse($Stream, [int]$StatusCode, [string]$StatusText, [string]$ContentType, [byte[]]$Body) {
    $header = "HTTP/1.1 $StatusCode $StatusText`r`nContent-Type: $ContentType`r`nContent-Length: $($Body.Length)`r`nCache-Control: no-store`r`nConnection: close`r`nX-Content-Type-Options: nosniff`r`n`r`n"
    $hb = [Text.Encoding]::ASCII.GetBytes($header)
    $Stream.Write($hb,0,$hb.Length)
    if ($Body.Length -gt 0) { $Stream.Write($Body,0,$Body.Length) }
    $Stream.Flush()
}

function Send-Json($Stream, $Object, [int]$Code=200) {
    $status = if($Code -eq 200){'OK'}elseif($Code -eq 404){'Not Found'}else{'Bad Request'}
    Write-HttpResponse $Stream $Code $status 'application/json; charset=utf-8' (Json-Bytes $Object)
}

function Handle-Request($Client) {
    $stream = $Client.GetStream()
    $reader = New-Object IO.StreamReader($stream, [Text.Encoding]::ASCII, $false, 8192, $true)
    try {
        $requestLine = $reader.ReadLine()
        if ([string]::IsNullOrWhiteSpace($requestLine)) { return }
        $parts = $requestLine.Split(' ')
        if ($parts.Count -lt 2) { return }
        $method = $parts[0].ToUpperInvariant(); $target = $parts[1]
        while ($true) { $line = $reader.ReadLine(); if ($null -eq $line -or $line -eq '') { break } }
        $path = Get-PathOnly $target
        $query = Get-QueryParams $target

        if ($path -eq '/api/health') {
            Send-Json $stream ([pscustomobject]@{ ok=$true; import_folder=$ImportFolder; materials=$script:Materials.Count; movements=$script:Movements.Count; mode='NO-INSTALL PowerShell' }); return
        }
        if ($path -eq '/api/dashboard') { Send-Json $stream (Get-Dashboard); return }
        if ($path -eq '/api/materials') {
            $q = if($query.ContainsKey('q')){[string]$query['q']}else{''}
            $status = if($query.ContainsKey('status')){[string]$query['status']}else{''}
            $pageSize = 200; if($query.ContainsKey('page_size')){ [void][int]::TryParse([string]$query['page_size'], [ref]$pageSize) }
            if($pageSize -lt 1){$pageSize=200}; if($pageSize -gt 1000){$pageSize=1000}
            $items = @($script:Materials)
            if(-not [string]::IsNullOrWhiteSpace($q)) { $qq=$q.ToLowerInvariant(); $items=@($items | Where-Object { ([string]$_.material).ToLowerInvariant().Contains($qq) -or ([string]$_.description).ToLowerInvariant().Contains($qq) -or ([string]$_.part_number).ToLowerInvariant().Contains($qq) }) }
            if(-not [string]::IsNullOrWhiteSpace($status)) { $items=@($items | Where-Object { $_.status -eq $status }) }
            $total=$items.Count; $items=@($items | Select-Object -First $pageSize)
            Send-Json $stream ([pscustomobject]@{total=$total;items=$items}); return
        }
        if ($path -match '^/api/materials/([^/]+)/movements$') {
            $mat=[Uri]::UnescapeDataString($matches[1]); $limit=80; if($query.ContainsKey('limit')){[void][int]::TryParse([string]$query['limit'],[ref]$limit)}
            $items=@($script:Movements | Where-Object { [string]$_.material -eq $mat } | Sort-Object posting_date -Descending | Select-Object -First $limit)
            Send-Json $stream ([pscustomobject]@{items=$items}); return
        }
        if ($path -match '^/api/materials/([^/]+)$') {
            $mat=[Uri]::UnescapeDataString($matches[1]); $item=$script:Materials | Where-Object { [string]$_.material -eq $mat } | Select-Object -First 1
            if($null -eq $item){Send-Json $stream ([pscustomobject]@{detail='Khong tim thay vat tu'}) 404}else{Send-Json $stream $item}; return
        }
        if ($path -eq '/api/admin/sync' -and $method -eq 'POST') {
            try { Send-Json $stream (Invoke-Sync) } catch { Send-Json $stream ([pscustomobject]@{detail=$_.Exception.Message}) 400 }; return
        }

        $rel = if($path -eq '/'){'index.html'}else{$path.TrimStart('/')}
        if($rel -notin @('index.html','app.js','styles.css')) { Send-Json $stream ([pscustomobject]@{detail='Not found'}) 404; return }
        $file = Join-Path $FrontendRoot $rel
        if(-not (Test-Path -LiteralPath $file)){Send-Json $stream ([pscustomobject]@{detail='Not found'}) 404; return}
        $bytes=[IO.File]::ReadAllBytes($file)
        $ct = if($rel.EndsWith('.html')){'text/html; charset=utf-8'}elseif($rel.EndsWith('.css')){'text/css; charset=utf-8'}else{'application/javascript; charset=utf-8'}
        Write-HttpResponse $stream 200 'OK' $ct $bytes
    } catch {
        try { Send-Json $stream ([pscustomobject]@{detail=$_.Exception.Message}) 400 } catch {}
    } finally {
        try{$reader.Dispose()}catch{}; try{$stream.Dispose()}catch{}; try{$Client.Close()}catch{}
    }
}

Load-State
if ($script:Materials.Count -eq 0) {
    try { $null = Invoke-Sync } catch { Write-Host ("Dong bo ban dau chua thanh cong: " + $_.Exception.Message) -ForegroundColor Yellow }
}

$ip = if($LanMode){[Net.IPAddress]::Any}else{[Net.IPAddress]::Loopback}
$listener = New-Object Net.Sockets.TcpListener($ip,$Port)
try {
    $listener.Start()
} catch {
    Write-Host "Khong mo duoc cong $Port. Co the cong dang duoc su dung hoac bi chinh sach cong ty chan." -ForegroundColor Red
    throw
}

Write-Host ''
Write-Host '=====================================================' -ForegroundColor DarkCyan
Write-Host ' STOCK LOCAL - NO INSTALL' -ForegroundColor Cyan
Write-Host '=====================================================' -ForegroundColor DarkCyan
Write-Host ("Local: http://localhost:$Port") -ForegroundColor Green
if($LanMode){
    try {
        $ips = [Net.Dns]::GetHostAddresses([Net.Dns]::GetHostName()) | Where-Object { $_.AddressFamily -eq [Net.Sockets.AddressFamily]::InterNetwork -and -not $_.IPAddressToString.StartsWith('127.') }
        foreach($a in $ips){ Write-Host ("LAN:   http://"+$a.IPAddressToString+":"+$Port) -ForegroundColor Green }
    } catch {}
}
Write-Host ("Data:  $ImportFolder")
Write-Host 'Nhan Ctrl+C de dung app.' -ForegroundColor Yellow
Write-Host ''

if($OpenBrowser){ try { Start-Process "http://localhost:$Port" } catch {} }

try {
    while ($true) {
        $client = $listener.AcceptTcpClient()
        Handle-Request $client
    }
} finally {
    try{$listener.Stop()}catch{}
}
