@echo off
setlocal
cd /d "%~dp0"
title STOCK LOCAL - NO INSTALL
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0StockServer.ps1"
if errorlevel 1 (
  echo.
  echo Khong the khoi dong STOCK LOCAL.
  echo Hay xem thong bao loi phia tren.
  pause
)
