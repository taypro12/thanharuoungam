STOCK LOCAL - BAN NO INSTALL CHO MAY CONG TY
============================================

MUC TIEU
- Khong can cai Python.
- Khong can pip / FastAPI / Node.js / npm.
- Khong can SQLite.
- Khong can quyen Administrator de chay local tren cong 8080.
- Giao dien web chay bang HTML/CSS/JavaScript offline.
- Backend dung Windows PowerShell + .NET co san tren Windows.
- Doc MB51/MB52 .xlsx thong qua Microsoft Excel dang cai tren may, che do READ-ONLY.

CHAY THU LAN DAU
1. Giai nen ca thu muc vao mot noi duoc phep, vi du:
   D:\StockLocal\

2. Chay:
   CHECK_MAY_CTY.bat
   Neu hien "Excel COM: OK" thi co the doc truc tiep MB51/MB52 .xlsx.

3. Chay:
   START_STOCK_APP.bat

4. Trinh duyet se mo:
   http://localhost:8080

5. App co san MB51_DEMO.xlsx + MB52_DEMO.xlsx va du lieu demo.

DUNG DU LIEU SAP THAT
- Xoa/doi ten 2 file DEMO trong:
  data\import\
- Chep file export SAP vao thu muc do. Ten file nen co MB51 va MB52, vi du:
  MB51_20260909.xlsx
  MB52_20260909.xlsx
- Mo app -> bam "Dong bo du lieu".
- App chi mo file Excel che do READ-ONLY, khong sua file nguon.

DOC TU O MANG / THU MUC CHUNG
Sua config.json, vi du:
{
  "port": 8080,
  "lan_mode": true,
  "import_folder": "\\\\SERVER\\SAP_EXPORT\\STOCK",
  "default_safety_days": 14,
  "default_lead_time_days": 30,
  "default_review_days": 30,
  "open_browser_on_start": true
}

MAY KHAC TRONG LAN
- Khi START_STOCK_APP.bat chay, cua so se hien dia chi LAN, vi du:
  http://192.168.1.50:8080
- May khac chi can mo dia chi do tren Chrome/Edge.
- Neu may khac khong truy cap duoc nhung localhost van duoc, kha nang cao Windows Firewall/chinh sach cong ty dang chan inbound. App khong tu y thay doi Firewall.

NEU POWERSHELL BI CHAN
- Neu chinh sach cong ty chan ca PowerShell script thi ban No Install nay se khong khoi dong duoc.
- Trong truong hop do, huong an phu hop nhat la Excel VBA .xlsm (neu Macro duoc phep) hoac nho IT whitelist app noi bo.

CAU TRUC
StockLocal\
  START_STOCK_APP.bat
  CHECK_MAY_CTY.bat
  StockServer.ps1
  config.json
  frontend\
  data\
    import\      <- MB51 / MB52
    state\       <- JSON app tu tao/cap nhat

ROP MAC DINH TRONG MVP
- Average daily usage: uu tien Usage 90 ngay / 90; neu khong co thi Usage 365 ngay / 365.
- Safety Stock = Average Daily Usage x Safety Days.
- ROP = Average Daily Usage x (Lead Time Days + Safety Days).
- Max Stock = Average Daily Usage x (Lead Time + Safety + Review Days).
- Tham so sua trong config.json.

LUU Y
- Mapping cot MB51/MB52 da ho tro cac ten cot SAP pho bien, nhung export thuc te cua cong ty co the co ten cot khac.
- Neu bam Dong bo bao "khong tim thay cot Material" hoac cot khac, can bo sung alias theo dung file export cua cong ty.
