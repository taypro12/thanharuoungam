const API='/api';
const $=s=>document.querySelector(s);
const $$=s=>[...document.querySelectorAll(s)];
const fmt=(v,d=0)=>Number(v||0).toLocaleString('vi-VN',{maximumFractionDigits:d});
const STATUS={SAFE:['An toàn','safe'],WATCH:['Theo dõi','watch'],CRITICAL:['Cần mua','critical'],OUT_OF_STOCK:['Hết hàng','out'],UNKNOWN:['Chưa đánh giá','unknown']};
function badge(v){const [l,c]=STATUS[v]||[v||'—','unknown'];return `<span class="status ${c}">${l}</span>`}
async function getJson(url,options){const r=await fetch(url,options);const x=await r.json();if(!r.ok)throw new Error(x.detail||'Có lỗi xảy ra');return x}
function setTab(tab){
  $$('.nav').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));
  $('#dashboard-view').classList.toggle('hidden',tab!=='dashboard');
  $('#materials-view').classList.toggle('hidden',tab!=='materials');
  $('#page-title').textContent=tab==='dashboard'?'Tổng quan tồn kho':'Tra cứu vật tư';
  if(tab==='materials')loadMaterials();
}
$$('.nav[data-tab]').forEach(b=>b.onclick=()=>setTab(b.dataset.tab));
$('#nav-alert').onclick=()=>{setTab('materials');$('#status-filter').value='CRITICAL';loadMaterials()};

async function loadDashboard(){
  const [d,h]=await Promise.all([getJson(`${API}/dashboard`),getJson(`${API}/health`)]);
  const cards=[['Tổng vật tư',d.total,'neutral','▦'],['An toàn',d.safe,'safe-card','✓'],['Cần theo dõi',d.watch,'watch-card','◷'],['Cần mua gấp',d.critical,'critical-card','!'],['Hết hàng',d.out_of_stock,'out-card','□']];
  $('#cards').innerHTML=cards.map(([l,v,c,i])=>`<div class="metric ${c}"><div><span>${l}</span><strong>${fmt(v)}</strong></div><i>${i}</i></div>`).join('');
  $('#critical-body').innerHTML=(d.critical_items||[]).map(x=>`<tr data-m="${x.material}"><td class="code">${x.material}</td><td>${x.description||'—'}</td><td class="num">${fmt(x.available,1)}</td><td class="num">${fmt(x.rop,1)}</td><td>${badge(x.status)}</td><td>›</td></tr>`).join('')||'<tr><td colspan="6" class="empty">Chưa có dữ liệu cảnh báo.</td></tr>';
  $('#critical-body').querySelectorAll('tr[data-m]').forEach(r=>r.onclick=()=>openMaterial(r.dataset.m));
  $('#latest-time').textContent=d.latest_import?.imported_at?.replace('T',' ')||'Chưa có';
  $('#latest-file').textContent=d.latest_import?.file_name||'—';
  $('#import-folder').textContent=h.import_folder||'—';
}

let searchTimer;
$('#search-input').addEventListener('input',()=>{clearTimeout(searchTimer);searchTimer=setTimeout(loadMaterials,180)});
$('#status-filter').addEventListener('change',loadMaterials);
async function loadMaterials(){
  const q=encodeURIComponent($('#search-input').value.trim());const s=encodeURIComponent($('#status-filter').value);
  const d=await getJson(`${API}/materials?q=${q}&status=${s}&page_size=200`);
  $('#result-count').textContent=`${fmt(d.total)} vật tư`;
  $('#materials-body').innerHTML=(d.items||[]).map(x=>`<tr data-m="${x.material}"><td class="code">${x.material}</td><td>${x.description||'—'}</td><td class="muted">${x.plant||'—'} / ${x.sloc||'—'}</td><td class="num">${fmt(x.unrestricted,1)}</td><td class="num strong">${fmt(x.available,1)}</td><td class="num">${fmt(x.rop,1)}</td><td class="num">${fmt(x.usage_90d,1)}</td><td class="num">${x.coverage_days==null?'—':fmt(x.coverage_days)+' ngày'}</td><td>${badge(x.status)}</td></tr>`).join('')||'<tr><td colspan="9" class="empty">Không tìm thấy vật tư.</td></tr>';
  $('#materials-body').querySelectorAll('tr[data-m]').forEach(r=>r.onclick=()=>openMaterial(r.dataset.m));
}
async function openMaterial(m){
  const [d,mv]=await Promise.all([getJson(`${API}/materials/${encodeURIComponent(m)}`),getJson(`${API}/materials/${encodeURIComponent(m)}/movements?limit=80`)]);
  $('#d-material').textContent=d.material;$('#d-description').textContent=d.description||'Chưa có mô tả';$('#d-status').innerHTML=badge(d.status);$('#d-updated').textContent=`Cập nhật: ${d.updated_at?.replace('T',' ')||'—'}`;
  const metrics=[['Tồn tự do',fmt(d.unrestricted,1)],['Khả dụng',fmt(d.available,1)],['ROP',fmt(d.rop,1)],['Safety Stock',fmt(d.safety_stock,1)],['Dùng 30 ngày',fmt(d.usage_30d,1)],['Dùng 90 ngày',fmt(d.usage_90d,1)],['Trung bình/ngày',fmt(d.avg_daily_usage,2)],['Coverage',d.coverage_days==null?'—':fmt(d.coverage_days)+' ngày']];
  $('#mini-grid').innerHTML=metrics.map(([a,b])=>`<div class="mini"><span>${a}</span><b>${b}</b></div>`).join('');
  const info=[['Plant',d.plant||'—'],['Storage Location',d.sloc||'—'],['ĐVT',d.uom||'—'],['Dự kiến hết hàng',d.estimated_stockout_date||'—']];
  $('#info-list').innerHTML=info.map(([a,b])=>`<div><span>${a}</span><b>${b}</b></div>`).join('');
  $('#movement-list').innerHTML=(mv.items||[]).map(x=>`<div class="movement"><div><b>${x.posting_date||'—'}</b><span>Mvt ${x.movement_type||'—'} • ${x.document||'Không có chứng từ'}</span></div><strong>${fmt(x.quantity,1)}</strong></div>`).join('')||'<div class="empty">Chưa có dữ liệu MB51 cho vật tư này.</div>';
  $('#drawer-backdrop').classList.remove('hidden');
}
$('#drawer-close').onclick=()=>$('#drawer-backdrop').classList.add('hidden');
$('#drawer-backdrop').onclick=e=>{if(e.target.id==='drawer-backdrop')e.currentTarget.classList.add('hidden')};
$('#sync-btn').onclick=async()=>{
  const b=$('#sync-btn');b.disabled=true;$('#sync-icon').classList.add('spin');$('#sync-text').textContent='Đang đồng bộ';
  try{const x=await getJson(`${API}/admin/sync`,{method:'POST'});const ni=(x.results||[]).filter(i=>!i.skipped).length,sk=(x.results||[]).filter(i=>i.skipped).length;showNotice(`Đồng bộ xong: ${ni} file mới, ${sk} file đã có${x.errors?.length?`, ${x.errors.length} lỗi`:''}.`);await Promise.all([loadDashboard(),loadMaterials()])}catch(e){showNotice('Lỗi: '+e.message,true)}finally{b.disabled=false;$('#sync-icon').classList.remove('spin');$('#sync-text').textContent='Đồng bộ dữ liệu'}
};
function showNotice(t,error=false){const n=$('#notice');n.textContent=t;n.classList.remove('hidden');n.classList.toggle('error',error);setTimeout(()=>n.classList.add('hidden'),6000)}
loadDashboard();loadMaterials();
