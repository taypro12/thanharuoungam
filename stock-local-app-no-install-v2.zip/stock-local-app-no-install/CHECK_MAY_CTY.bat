@echo off
setlocal
cd /d "%~dp0"
title STOCK LOCAL - KIEM TRA MAY
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Continue'; Write-Host '=== STOCK LOCAL - KIEM TRA MAY ===' -ForegroundColor Cyan; Write-Host ('PowerShell: ' + $PSVersionTable.PSVersion); try { $e=New-Object -ComObject Excel.Application; Write-Host ('Excel COM: OK - Version ' + $e.Version) -ForegroundColor Green; $e.Quit(); [void][Runtime.InteropServices.Marshal]::ReleaseComObject($e) } catch { Write-Host ('Excel COM: KHONG DUNG DUOC - ' + $_.Exception.Message) -ForegroundColor Red }; Write-Host ('Thu muc: ' + (Get-Location)); Write-Host 'Neu Excel COM = OK thi app co the doc MB51/MB52 .xlsx ma khong can cai thu vien.'; Read-Host 'Nhan Enter de dong'"
